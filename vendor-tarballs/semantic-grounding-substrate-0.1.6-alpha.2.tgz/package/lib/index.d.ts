import { z } from "zod";
//#region src/types.d.ts
/**
 * Mirrors canonicalize_type: complex/parametrized types (array<...>, map<...>,
 * struct<...>, decimal(p,s)) preserved verbatim; unknown scalars pass through.
 * @param raw - the physical type spelling to canonicalize (empty string passes through).
 * @returns the canonical logical type, or the verbatim input for complex/unknown types.
 */
declare function canonicalizeType(raw: string): string;
/** Zod schema for a table/event confirmation record (status + confirmed_by + confirmed_at); mirrors RBI Confirmation. */
declare const ConfirmationSchema: z.ZodObject<{
  status: z.ZodDefault<z.ZodString>;
  confirmed_by: z.ZodDefault<z.ZodString>;
  confirmed_at: z.ZodDefault<z.ZodString>;
}, z.core.$loose>;
/** Inferred type of {@link ConfirmationSchema} (status + confirmed_by + confirmed_at). */
type Confirmation = z.infer<typeof ConfirmationSchema>;
/** Zod schema for a coverage report (scenarios + limitations + status); mirrors RBI CoverageDef. */
declare const CoverageDefSchema: z.ZodObject<{
  scenarios: z.ZodDefault<z.ZodArray<z.ZodString>>;
  limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
  coverage_status: z.ZodDefault<z.ZodString>;
}, z.core.$loose>;
/** Inferred type of {@link CoverageDefSchema} (scenarios + limitations + coverage_status). */
type CoverageDef = z.infer<typeof CoverageDefSchema>;
/** Zod schema for a supersession record (an upstream table this one replaces + when/advantage); mirrors RBI SupersedesDef. */
declare const SupersedesDefSchema: z.ZodObject<{
  source: z.ZodString;
  when: z.ZodDefault<z.ZodString>;
  advantage: z.ZodDefault<z.ZodString>;
}, z.core.$loose>;
/** Inferred type of {@link SupersedesDefSchema} (source + when + advantage). */
type SupersedesDef = z.infer<typeof SupersedesDefSchema>;
/** Zod schema for a single event parameter field (canonicalized type + description); mirrors RBI ParamField. */
declare const ParamFieldSchema: z.ZodObject<{
  type: z.ZodPipe<z.ZodDefault<z.ZodString>, z.ZodTransform<string, string>>;
  description: z.ZodDefault<z.ZodString>;
}, z.core.$loose>;
/** Inferred type of {@link ParamFieldSchema} (canonicalized type + description). */
type ParamField = z.infer<typeof ParamFieldSchema>;
/** Zod schema for a caliber variant (id + description + default flag); mirrors RBI CaliberVariant. */
declare const CaliberVariantSchema: z.ZodObject<{
  id: z.ZodString;
  description: z.ZodDefault<z.ZodString>;
  default: z.ZodDefault<z.ZodBoolean>;
}, z.core.$loose>;
/** Inferred type of {@link CaliberVariantSchema} (id + description + default). */
type CaliberVariant = z.infer<typeof CaliberVariantSchema>;
/**
 * Zod schema for a metric definition (expression + description + caliber
 * variants), refined so at most one variant may declare `default`; mirrors RBI MetricDef.
 */
declare const MetricDefSchema: z.ZodObject<{
  expression: z.ZodDefault<z.ZodString>;
  description: z.ZodDefault<z.ZodString>;
  alt_labels: z.ZodDefault<z.ZodArray<z.ZodString>>;
  caliber_variants: z.ZodDefault<z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    description: z.ZodDefault<z.ZodString>;
    default: z.ZodDefault<z.ZodBoolean>;
  }, z.core.$loose>>>;
}, z.core.$loose>;
/** Inferred type of {@link MetricDefSchema} (expression + description + caliber_variants). */
type MetricDef = z.infer<typeof MetricDefSchema>;
/**
 * The derived MetricDefinition — produced at retrieval time from a table/event
 * embedded `metrics:` block (NOT loaded from a standalone YAML file). Carries
 * `caliber_variants` (M1c: planner Type B disambiguation signal).
 */
declare const MetricDefinitionSchema: z.ZodObject<{
  kind: z.ZodDefault<z.ZodLiteral<"metric">>;
  name: z.ZodString;
  description: z.ZodDefault<z.ZodString>;
  pref_label: z.ZodOptional<z.ZodString>;
  alt_labels: z.ZodDefault<z.ZodArray<z.ZodString>>;
  domains: z.ZodDefault<z.ZodArray<z.ZodString>>;
  computation: z.ZodDefault<z.ZodObject<{
    sql: z.ZodDefault<z.ZodString>;
    metadata: z.ZodDefault<z.ZodObject<{
      aggregation: z.ZodDefault<z.ZodString>;
      field: z.ZodDefault<z.ZodString>;
      source: z.ZodDefault<z.ZodString>;
      time_grain: z.ZodDefault<z.ZodString>;
    }, z.core.$loose>>;
  }, z.core.$loose>>;
  relations: z.ZodDefault<z.ZodArray<z.ZodObject<{
    type: z.ZodEnum<{
      joins: "joins";
      derived_from: "derived_from";
      related_to: "related_to";
    }>;
    target: z.ZodString;
    on: z.ZodDefault<z.ZodString>;
    description: z.ZodDefault<z.ZodString>;
  }, z.core.$loose>>>;
  caliber_variants: z.ZodDefault<z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    description: z.ZodDefault<z.ZodString>;
    default: z.ZodDefault<z.ZodBoolean>;
  }, z.core.$loose>>>;
}, z.core.$loose>;
/** Inferred type of {@link MetricDefinitionSchema} — the derived metric produced at retrieval time. */
type MetricDefinition = z.infer<typeof MetricDefinitionSchema>;
/** Zod schema for an event disambiguation rule (event + trigger + distinction); mirrors RBI Disambiguation. */
declare const DisambiguationSchema: z.ZodObject<{
  event: z.ZodString;
  trigger: z.ZodDefault<z.ZodString>;
  distinction: z.ZodDefault<z.ZodString>;
}, z.core.$loose>;
/** Inferred type of {@link DisambiguationSchema} (event + trigger + distinction). */
type Disambiguation = z.infer<typeof DisambiguationSchema>;
/** Zod schema for a table's default terminology map (term name -> term text); mirrors RBI TableTermDefaults. */
declare const TableTermDefaultsSchema: z.ZodObject<{
  term_defaults: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
}, z.core.$loose>;
/** Inferred type of {@link TableTermDefaultsSchema} (term_defaults map). */
type TableTermDefaults = z.infer<typeof TableTermDefaultsSchema>;
/** Zod schema for a dimension key-pair (dws_column <-> dim_column join key); mirrors RBI DimensionKeyPair. */
declare const DimensionKeyPairSchema: z.ZodObject<{
  dws_column: z.ZodString;
  dim_column: z.ZodString;
}, z.core.$loose>;
/** Inferred type of {@link DimensionKeyPairSchema} (dws_column + dim_column). */
type DimensionKeyPair = z.infer<typeof DimensionKeyPairSchema>;
/**
 * Zod schema for an external dimension reference (dim_table + join_keys +
 * derivation), refined so `join_keys` must contain at least one pair; mirrors RBI DimensionRef.
 */
declare const DimensionRefSchema: z.ZodObject<{
  dim_table: z.ZodString;
  join_keys: z.ZodArray<z.ZodObject<{
    dws_column: z.ZodString;
    dim_column: z.ZodString;
  }, z.core.$loose>>;
  derivation: z.ZodDefault<z.ZodString>;
  origin: z.ZodOptional<z.ZodEnum<{
    deterministic: "deterministic";
    llm: "llm";
    manual: "manual";
  }>>;
}, z.core.$loose>;
/** Inferred type of {@link DimensionRefSchema} (dim_table + join_keys + derivation). */
type DimensionRef = z.infer<typeof DimensionRefSchema>;
/**
 * Zod schema for an event definition (埋点: name + params_fields + metrics +
 * disambiguation + external_refs + confirmation + coverage); mirrors RBI EventDefinition.
 */
declare const EventDefinitionSchema: z.ZodObject<{
  name: z.ZodString;
  event_filter: z.ZodDefault<z.ZodString>;
  description: z.ZodDefault<z.ZodString>;
  pref_label: z.ZodOptional<z.ZodString>;
  alt_labels: z.ZodDefault<z.ZodArray<z.ZodString>>;
  domains: z.ZodDefault<z.ZodArray<z.ZodString>>;
  params_fields: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
    type: z.ZodPipe<z.ZodDefault<z.ZodString>, z.ZodTransform<string, string>>;
    description: z.ZodDefault<z.ZodString>;
  }, z.core.$loose>>>;
  metrics: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
    expression: z.ZodDefault<z.ZodString>;
    description: z.ZodDefault<z.ZodString>;
    alt_labels: z.ZodDefault<z.ZodArray<z.ZodString>>;
    caliber_variants: z.ZodDefault<z.ZodArray<z.ZodObject<{
      id: z.ZodString;
      description: z.ZodDefault<z.ZodString>;
      default: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$loose>>>;
  }, z.core.$loose>>>;
  disambiguation: z.ZodDefault<z.ZodArray<z.ZodObject<{
    event: z.ZodString;
    trigger: z.ZodDefault<z.ZodString>;
    distinction: z.ZodDefault<z.ZodString>;
  }, z.core.$loose>>>;
  external_refs: z.ZodDefault<z.ZodArray<z.ZodObject<{
    dim_table: z.ZodString;
    join_keys: z.ZodArray<z.ZodObject<{
      dws_column: z.ZodString;
      dim_column: z.ZodString;
    }, z.core.$loose>>;
    derivation: z.ZodDefault<z.ZodString>;
    origin: z.ZodOptional<z.ZodEnum<{
      deterministic: "deterministic";
      llm: "llm";
      manual: "manual";
    }>>;
  }, z.core.$loose>>>;
  confirmation: z.ZodDefault<z.ZodObject<{
    status: z.ZodDefault<z.ZodString>;
    confirmed_by: z.ZodDefault<z.ZodString>;
    confirmed_at: z.ZodDefault<z.ZodString>;
  }, z.core.$loose>>;
  coverage: z.ZodDefault<z.ZodNullable<z.ZodObject<{
    scenarios: z.ZodDefault<z.ZodArray<z.ZodString>>;
    limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
    coverage_status: z.ZodDefault<z.ZodString>;
  }, z.core.$loose>>>;
}, z.core.$loose>;
/** Inferred type of {@link EventDefinitionSchema} (the parsed event-definition shape). */
type EventDefinition = z.infer<typeof EventDefinitionSchema>;
/** Zod schema for a single table column (name + canonicalized type + comment + role); mirrors RBI ColumnDef. */
declare const ColumnDefSchema: z.ZodObject<{
  name: z.ZodString;
  type: z.ZodPipe<z.ZodDefault<z.ZodString>, z.ZodTransform<string, string>>;
  comment: z.ZodDefault<z.ZodString>;
  role: z.ZodDefault<z.ZodString>;
}, z.core.$loose>;
/** Inferred type of {@link ColumnDefSchema} (name + type + comment + role). */
type ColumnDef = z.infer<typeof ColumnDefSchema>;
/** Zod schema for a single table partition (name + canonicalized type); mirrors RBI PartitionDef. */
declare const PartitionDefSchema: z.ZodObject<{
  name: z.ZodString;
  type: z.ZodPipe<z.ZodDefault<z.ZodString>, z.ZodTransform<string, string>>;
}, z.core.$loose>;
/** Inferred type of {@link PartitionDefSchema} (name + type). */
type PartitionDef = z.infer<typeof PartitionDefSchema>;
/**
 * Zod schema for a table definition (表: name + columns + metrics + partitions
 * + kind + primary_key + label_columns + dimension_refs + confirmation +
 * coverage + supersedes + disambiguation), refined so DIM-kind tables must
 * declare a non-empty `primary_key` and `label_columns`; mirrors RBI TableDefinition.
 */
declare const TableDefinitionSchema: z.ZodObject<{
  table_name: z.ZodString;
  project: z.ZodOptional<z.ZodString>;
  table_comment: z.ZodDefault<z.ZodString>;
  description: z.ZodDefault<z.ZodString>;
  pref_label: z.ZodOptional<z.ZodString>;
  alt_labels: z.ZodDefault<z.ZodArray<z.ZodString>>;
  domains: z.ZodDefault<z.ZodArray<z.ZodString>>;
  granularity: z.ZodDefault<z.ZodString>;
  engine: z.ZodDefault<z.ZodString>;
  columns: z.ZodDefault<z.ZodArray<z.ZodObject<{
    name: z.ZodString;
    type: z.ZodPipe<z.ZodDefault<z.ZodString>, z.ZodTransform<string, string>>;
    comment: z.ZodDefault<z.ZodString>;
    role: z.ZodDefault<z.ZodString>;
  }, z.core.$loose>>>;
  metrics: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
    expression: z.ZodDefault<z.ZodString>;
    description: z.ZodDefault<z.ZodString>;
    alt_labels: z.ZodDefault<z.ZodArray<z.ZodString>>;
    caliber_variants: z.ZodDefault<z.ZodArray<z.ZodObject<{
      id: z.ZodString;
      description: z.ZodDefault<z.ZodString>;
      default: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$loose>>>;
  }, z.core.$loose>>>;
  partitions: z.ZodDefault<z.ZodArray<z.ZodObject<{
    name: z.ZodString;
    type: z.ZodPipe<z.ZodDefault<z.ZodString>, z.ZodTransform<string, string>>;
  }, z.core.$loose>>>;
  confirmation: z.ZodDefault<z.ZodObject<{
    status: z.ZodDefault<z.ZodString>;
    confirmed_by: z.ZodDefault<z.ZodString>;
    confirmed_at: z.ZodDefault<z.ZodString>;
  }, z.core.$loose>>;
  coverage: z.ZodDefault<z.ZodNullable<z.ZodObject<{
    scenarios: z.ZodDefault<z.ZodArray<z.ZodString>>;
    limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
    coverage_status: z.ZodDefault<z.ZodString>;
  }, z.core.$loose>>>;
  supersedes: z.ZodDefault<z.ZodArray<z.ZodObject<{
    source: z.ZodString;
    when: z.ZodDefault<z.ZodString>;
    advantage: z.ZodDefault<z.ZodString>;
  }, z.core.$loose>>>;
  disambiguation: z.ZodDefault<z.ZodNullable<z.ZodObject<{
    term_defaults: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
  }, z.core.$loose>>>;
  kind: z.ZodDefault<z.ZodEnum<{
    dws: "dws";
    dim: "dim";
  }>>;
  primary_key: z.ZodDefault<z.ZodArray<z.ZodString>>;
  primary_key_unique: z.ZodDefault<z.ZodNullable<z.ZodBoolean>>;
  duplicate_sample: z.ZodDefault<z.ZodArray<z.ZodRecord<z.ZodString, z.ZodString>>>;
  label_columns: z.ZodDefault<z.ZodArray<z.ZodString>>;
  freshness: z.ZodPreprocess<z.ZodDefault<z.ZodEnum<{
    "": "";
    static_reference: "static_reference";
    "T+1": "T+1";
  }>>, unknown>;
  dimension_refs: z.ZodDefault<z.ZodArray<z.ZodObject<{
    dim_table: z.ZodString;
    join_keys: z.ZodArray<z.ZodObject<{
      dws_column: z.ZodString;
      dim_column: z.ZodString;
    }, z.core.$loose>>;
    derivation: z.ZodDefault<z.ZodString>;
    origin: z.ZodOptional<z.ZodEnum<{
      deterministic: "deterministic";
      llm: "llm";
      manual: "manual";
    }>>;
  }, z.core.$loose>>>;
}, z.core.$loose>;
/** Inferred type of {@link TableDefinitionSchema} (the parsed table-definition shape). */
type TableDefinition = z.infer<typeof TableDefinitionSchema>;
/** Zod schema for a single connector column meta (name + type + optional comment); mirrors RBI TableMeta's column shape. */
declare const ColumnMetaSchema: z.ZodObject<{
  name: z.ZodString;
  type: z.ZodString;
  comment: z.ZodNullable<z.ZodOptional<z.ZodString>>;
}, z.core.$strip>;
/** Inferred type of {@link ColumnMetaSchema} (name + type + optional comment). */
type ColumnMeta = z.infer<typeof ColumnMetaSchema>;
/** Zod schema for a single connector partition meta (name + type); mirrors RBI TableMeta's partition shape. */
declare const PartitionMetaSchema: z.ZodObject<{
  name: z.ZodString;
  type: z.ZodString;
}, z.core.$strip>;
/** Inferred type of {@link PartitionMetaSchema} (name + type). */
type PartitionMeta = z.infer<typeof PartitionMetaSchema>;
/**
 * Zod schema for the schema-dict shape a `DataSourceConnector` returns (the
 * input to sync-write, not a semantic definition): table_name + columns +
 * partitions + optional comment. Mirrors rbi-semantic/sync.py:TableMeta.
 */
declare const TableMetaSchema: z.ZodObject<{
  table_name: z.ZodString;
  columns: z.ZodDefault<z.ZodArray<z.ZodObject<{
    name: z.ZodString;
    type: z.ZodString;
    comment: z.ZodNullable<z.ZodOptional<z.ZodString>>;
  }, z.core.$strip>>>;
  partitions: z.ZodDefault<z.ZodArray<z.ZodObject<{
    name: z.ZodString;
    type: z.ZodString;
  }, z.core.$strip>>>;
  comment: z.ZodNullable<z.ZodOptional<z.ZodString>>;
}, z.core.$loose>;
/** Inferred type of {@link TableMetaSchema} (the connector-returned table-meta shape). */
type TableMeta = z.infer<typeof TableMetaSchema>;
/**
 * Zod schema for a concept definition (CL-2: first-class entity in concepts/ dir).
 * Concepts represent semantic domains as explicit graph nodes; asset.domains
 * values are validated against concept names at load time.
 */
declare const ConceptDefinitionSchema: z.ZodObject<{
  name: z.ZodString;
  description: z.ZodDefault<z.ZodString>;
  pref_label: z.ZodOptional<z.ZodString>;
  alt_labels: z.ZodDefault<z.ZodArray<z.ZodString>>;
}, z.core.$loose>;
/** Inferred type of {@link ConceptDefinitionSchema}. */
type ConceptDefinition = z.infer<typeof ConceptDefinitionSchema>;
//#endregion
//#region src/corpus.d.ts
/**
 * Corpus enrichment — pure projection from semantic-layer events to a retrieval
 * corpus. Packs `params_fields` (field name + field description) + `alt_labels`
 * (SKOS aliases from definition) into the indexed `description`; does NOT index
 * `domain` (probe refuted it).
 *
 * The output shape (`EventCorpusItem`) is structurally identical to the
 * retrieval sinks — `DataSourceDoc` (nl2sql-engine `Bm25Linker`) and
 * `RetrievalCorpusItem` (retrieval-inproc `HybridRetriever`): all are
 * `{ id, description?, metrics?, payload? }`. No runtime dep on either: the
 * `Bm25Linker`/`HybridRetriever` `buildCorpus` applies field weights as token
 * repetition over this shape, so a richer `description` raises recall without
 * touching `FIELD_WEIGHTS`.
 *
 * @module corpus (internal; only `"."` is importable — see ADR-0002)
 */
/** Event projected to the fields the retrieval corpus indexes — a subset of
 * `RawEvent.raw` / `EventDefinition`. `domain` is deliberately absent: it is
 * not indexed (probe refuted it). */
interface EventCorpusInput {
  /** Event name (becomes the corpus `id`). */
  readonly name: string;
  /** Short human description; indexed ×1 (per the sink's description field weight). */
  readonly description?: string;
  /** Per-field `{ type, description }`; the field name + description are packed
   * into the indexed text — this is where the rich semantic content lives. */
  readonly params_fields?: Readonly<Record<string, {
    readonly description?: string;
  }>>;
  /** SKOS altLabel aliases from the definition's `alt_labels` field. */
  readonly alt_labels?: readonly string[];
  /** Metric definitions keyed by name; the metric names are carried through for
   * the sink to index (×1 / ×4 per the sink's metric field weight). */
  readonly metrics?: Readonly<Record<string, unknown>>;
}
/** A corpus item the retriever indexes (DataSourceDoc / RetrievalCorpusItem-shaped). */
interface EventCorpusItem {
  /** Unique identifier (event name); repeated by the sink's `id`/`name` field weight. */
  readonly id: string;
  /** Enriched description (event desc + params_fields name+desc + terminology
   * slang); repeated by the sink's description field weight. */
  readonly description?: string;
  /** Metric definitions keyed by name; each name is repeated by the sink's metric field weight. */
  readonly metrics?: Readonly<Record<string, unknown>>;
  /** Opaque payload — the original event (short description + params_fields) carried through to the hit. */
  readonly payload?: unknown;
}
/** D2h (2026-08-21): the enrichment variant — which slices of each event pack
 * into the indexed `description`. `params+term` (default, the D2e-shipped form)
 * packs the event description + params_fields (field name + desc) + terminology
 * slang; `term-only` packs the event description + terminology slang ONLY
 * (drops params_fields — the D2g verdict (A) higher-recall form on the shipped
 * Bm25Linker: 77.0% strict vs params+term 68.1% on 113 gold; best
 * term@topK=20 = 85.0%). `params-only` is NOT shipped (D2g measured it 63.7%
 * strict, strictly worse than params+term 68.1% + degenerate with
 * params+term-on-no-slang); a future ticket can add it as a non-breaking enum
 * extension. The variant is a mount-time SemanticLayerConfig choice (not
 * mid-session); switching it remounts the Service (new WeakMap key -> fresh
 * enriched linker), so it is NOT part of the D2f corpusVersion cache key. */
type CorpusVariant = 'params+term' | 'term-only';
/**
 * Build an enriched retrieval corpus from semantic-layer events. Each item's
 * `description` packs the event description + alt_labels (SKOS aliases from
 * the definition); `params+term` (default) ALSO packs params_fields (field
 * name + field description). `term-only` drops params_fields. `domain` is NOT
 * indexed (probe refuted it). The original event is carried as `payload`.
 * @param events - the events to project (RawEvent.raw / EventDefinition subset).
 * @param variant - which slices to pack: 'params+term' (default, shipped) or 'term-only'.
 * @returns corpus items ready for `Bm25Linker` / `HybridRetriever` indexing.
 */
declare function buildRetrievalCorpus(events: readonly EventCorpusInput[], variant?: CorpusVariant): readonly EventCorpusItem[];
//#endregion
//#region src/io.d.ts
/** Tier-2 recorder contract — `ctx.audit` satisfies this (P6b grilling Q4). */
interface Tier2Recorder {
  recordTier2Write(toolName: string, payload: unknown, opts?: {
    readonly scope_id?: string;
    readonly session_id?: string;
    readonly tenant_id?: string;
    readonly user_id?: string;
  }): string;
}
/** Tier-2 write options: the recorder (ctx.audit) and optional scope id. */
interface Tier2Opts {
  /** ctx.audit (or a test double) — required; Tier-2 audit is non-disableable (D5 "不可关"). */
  readonly recorder: Tier2Recorder;
  readonly scope_id?: string;
}
/**
 * Dump a value to YAML (mirrors RBI `_LiteralDumper`: literal block style, sort_keys=False).
 * @param obj - the value to serialize.
 * @returns the YAML text (no refs, double-quote strings, unbounded line width).
 */
declare function dumpYaml(obj: unknown): string;
/**
 * Fire every registered invalidation hook for `semanticLayer` (best-effort: a broken hook cannot block the write).
 * @param semanticLayer - the semantic-layer path being invalidated.
 */
declare function invalidateCaches(semanticLayer: string): void;
/**
 * Resolve the semantic-layer dir from a root: returns the root itself when it
 * holds `config.yaml`, otherwise the first child subdir that does (falls back
 * to the root when none matches).
 * @param semanticRoot - the root path to resolve from (empty string passes through).
 * @returns the resolved semantic-layer directory path.
 */
declare function resolveSemanticLayer(semanticRoot: string): string;
/**
 * Read and parse the layer's `config.yaml` (the caller is responsible for ensuring it exists).
 * @param semanticLayer - the semantic-layer directory path.
 * @returns the parsed config map.
 */
declare function loadConfig(semanticLayer: string): Record<string, unknown>;
/**
 * Read and parse the layer's `domains.yaml` catalog (lenient: missing/malformed => `{}`).
 * @param semanticLayer - the semantic-layer directory path.
 * @returns the parsed domains map, or `{}` when the file is absent or not an object.
 */
declare function loadDomains(semanticLayer: string): Record<string, unknown>;
/** A scanned event: its `name`, raw YAML dict, and the domain subdir it lived in (unvalidated). */
interface RawEvent {
  readonly name: string;
  readonly raw: Record<string, unknown>;
  readonly domain: string;
}
/**
 * Scan the layer's `events/` subdirs (lenient: broken/non-object/unnamed YAML
 * files are skipped) and collect every event with its domain.
 * @param semanticLayer - the semantic-layer directory path.
 * @returns a fresh array of raw events (name + raw + domain), oldest-first within each domain.
 */
declare function loadEvents(semanticLayer: string): RawEvent[];
/** A scanned table: its file path, `table_name`, and raw YAML dict (unvalidated). */
interface RawTable {
  readonly path: string;
  readonly table_name: string;
  readonly raw: Record<string, unknown>;
}
/**
 * Scan the layer's `tables/` dir (lenient: broken/non-object/unnamed YAML
 * files are skipped; `_`-prefixed files ignored) and collect every table.
 * @param semanticLayer - the semantic-layer directory path.
 * @returns a fresh array of raw tables (path + table_name + raw), name-sorted.
 */
declare function loadTables(semanticLayer: string): RawTable[];
/**
 * Load a validated event definition by name (strict validate-on-match; lenient scan).
 * @param semanticLayer - the semantic-layer directory path.
 * @param name - the event `name` key to match.
 * @returns the parsed `EventDefinition`, or null when no event matches.
 */
declare function loadEventDefinition(semanticLayer: string, name: string): EventDefinition | null;
/**
 * Load a validated table definition by name (strict validate-on-match; lenient scan).
 * @param semanticLayer - the semantic-layer directory path.
 * @param name - the table `table_name` key to match.
 * @returns the parsed `TableDefinition`, or null when no table matches.
 */
declare function loadTableDefinition(semanticLayer: string, name: string): TableDefinition | null;
/** A scanned concept: its `name` and raw YAML dict (unvalidated). */
interface RawConcept {
  readonly name: string;
  readonly raw: Record<string, unknown>;
}
/**
 * Scan the layer's `concepts/` dir (lenient: broken/non-object/unnamed YAML
 * files are skipped) and collect every concept.
 * @param semanticLayer - the semantic-layer directory path.
 * @returns a fresh array of raw concepts (name + raw), name-sorted.
 */
declare function loadConcepts(semanticLayer: string): RawConcept[];
/**
 * Load a validated concept definition by name.
 * @param semanticLayer - the semantic-layer directory path.
 * @param name - the concept `name` key to match.
 * @returns the parsed `ConceptDefinition`, or null when no concept matches.
 */
declare function loadConceptDefinition(semanticLayer: string, name: string): ConceptDefinition | null;
/**
 * Generic flat scan of `<semanticLayer>/<dir>/*.yaml` returning each file's raw
 * object dict (lenient: broken/non-object YAML and `_`-prefixed files skipped).
 * The kind-agnostic reader for storage dirs without a bespoke loader — used by
 * the registry-driven graph projection (W27) so a kind registered after build
 * can load its definitions without a hardcoded per-kind loader. Bespoke layouts
 * (events' domain subdirs, tables) keep their own loaders.
 * @param semanticLayer - the semantic-layer directory path.
 * @param dir - the storage subdirectory name.
 * @returns a fresh array of raw object dicts, filename-sorted.
 */
declare function loadRawDir(semanticLayer: string, dir: string): Record<string, unknown>[];
/**
 * Build an enriched retrieval corpus from the substrate. Each event's
 * `alt_labels` (SKOS aliases) + params_fields are packed into the indexed
 * description. Lenient: an unreadable events/ scan degrades to an empty
 * corpus rather than throwing.
 * @param semanticLayer - the semantic-layer directory path (with `events/`).
 * @param variant - which slices to pack: 'params+term' (default) or 'term-only'.
 * @returns enriched corpus items ready for `Bm25Linker` / `HybridRetriever` indexing.
 */
declare function loadRetrievalCorpus(semanticLayer: string, variant?: CorpusVariant): readonly EventCorpusItem[];
/** Error thrown by `writeTable` when `TableDefinitionSchema.safeParse` rejects the payload (unless `skipValidation` is set). */
declare class WriteValidationError extends Error {}
/**
 * Validate-then-atomically-write a table YAML (mirrors writer.write_table),
 * invalidating caches on success.
 * @param semanticLayer - the semantic-layer directory path.
 * @param name - the table `table_name` (becomes the `<name>.yaml` filename).
 * @param data - the table payload; validated against `TableDefinitionSchema` unless skipped.
 * @param opts - `{ skipValidation: true }` skips schema validation (for pre-validated generators).
 * @returns the absolute path of the written `<name>.yaml` under `tables/`.
 */
declare function writeTable(semanticLayer: string, name: string, data: unknown, opts?: {
  skipValidation?: boolean;
}): Promise<string>;
/**
 * Result of writing event YAML: either `{ ok: true, path }` on success or
 * `{ ok: false, error }` when the YAML is unparseable/not-an-object or its
 * `name` does not match `name`.
 */
type WriteEventYamlResult = {
  ok: true;
  path: string;
} | {
  ok: false;
  error: string;
};
/**
 * Raw-edit surface for event YAML: parse the content, verify its `name` matches,
 * then atomically write it to the discovered event path (or
 * `events/_suggested/<name>.yaml` when new). No schema validation — the write
 * IS the repair surface; `loadEvents` validates on read.
 * @param semanticLayer - the semantic-layer directory path.
 * @param name - the event `name` the content must declare.
 * @param content - the raw YAML text to write verbatim.
 * @returns `{ ok: true, path }` on success, or `{ ok: false, error }` describing the parse/name-mismatch failure.
 */
declare function writeEventYaml(semanticLayer: string, name: string, content: string): Promise<WriteEventYamlResult>;
/**
 * Result of a Tier-2 table-meta update: `{ ok: true, table_name }` on success,
 * or `{ ok: false, error }` when the table is missing/malformed or post-merge
 * validation fails.
 */
type UpdateTableMetaResult = {
  ok: true;
  table_name: string;
} | {
  ok: false;
  error: string;
};
/**
 * Tier-2 per-scope write: read-merge-validate-write a single table's meta
 * updates and record the write via `opts.recorder` (D5 non-disableable audit).
 * @param semanticLayer - the semantic-layer directory path.
 * @param name - the table `table_name` to update (must already exist on disk).
 * @param updates - the field overrides merged over the existing table YAML.
 * @param opts - the recorder + optional scope id used for the Tier-2 audit record.
 * @returns `{ ok: true, table_name }` on success, or `{ ok: false, error }` when the table is missing/malformed or validation fails.
 */
declare function updateTableMeta(semanticLayer: string, name: string, updates: Record<string, unknown>, opts: Tier2Opts): Promise<UpdateTableMetaResult>;
/**
 * Result of a Tier-2 event-meta update: `{ ok: true, event_name }` on success,
 * or `{ ok: false, error }` when the event is missing/malformed or post-merge
 * validation fails.
 */
type UpdateEventMetaResult = {
  ok: true;
  event_name: string;
} | {
  ok: false;
  error: string;
};
/**
 * Tier-2 per-scope write: read-merge-validate-write a single event's meta
 * updates and record the write via `opts.recorder` (D5 non-disableable audit).
 * Mirrors `updateTableMeta` for the event substrate (A13 TOCTOU fix).
 * @param semanticLayer - the semantic-layer directory path.
 * @param name - the event `name` to update (must already exist on disk).
 * @param updates - the field overrides merged over the existing event YAML.
 * @param opts - the recorder + optional scope id used for the Tier-2 audit record.
 * @returns `{ ok: true, event_name }` on success, or `{ ok: false, error }` when the event is missing/malformed or validation fails.
 */
declare function updateEventMeta(semanticLayer: string, name: string, updates: Record<string, unknown>, opts: Tier2Opts): Promise<UpdateEventMetaResult>;
type MergeColumn = {
  name: string;
  type: string;
  role?: string;
  comment?: string;
};
/**
 * Infer a column's semantic role (dimension/measure/attribute) from its name + type (mirrors RBI infer_role).
 * @param col - the column with optional `name`/`type` (defaults apply when absent).
 * @returns the inferred role: `dimension`, `measure`, or `attribute`.
 */
declare function inferRole(col: {
  name?: string;
  type?: string;
}): string;
/**
 * Generate a DWS (fact) table YAML skeleton from a table meta (mirrors sync.generate_table_yaml).
 * @param meta - the table meta (name + columns + partitions + comment) to generate from.
 * @returns a draft `TableDefinition`-shaped dict (confirmation=draft, empty description/granularity).
 */
declare function generateTableYaml(meta: TableMeta): Record<string, unknown>;
/**
 * Generate a DIM (dimension) table YAML skeleton from a table meta, deriving
 * `primary_key` (first `*_id` column) and `label_columns` (string columns
 * ending in label suffixes) for `.superRefine` validation (mirrors sync.generate_dim_yaml).
 * @param meta - the table meta to generate the dimension table from.
 * @returns a draft DIM `TableDefinition`-shaped dict (kind='dim', confirmation=draft).
 */
declare function generateDimYaml(meta: TableMeta): Record<string, unknown>;
/**
 * Merge new table-meta columns over existing columns, preserving analyst role
 * corrections (an existing `role` overrides the inferred role; a missing
 * column is inferred fresh). Mirrors sync.merge_columns.
 * @param existingCols - the existing columns carrying analyst role overrides.
 * @param newMetaCols - the freshly-fetched columns to merge over.
 * @returns the merged columns (each with a non-empty `role` and `comment`).
 */
declare function mergeColumns(existingCols: ReadonlyArray<MergeColumn>, newMetaCols: ReadonlyArray<{
  name: string;
  type: string;
  comment?: string | null | undefined;
}>): Array<{
  name: string;
  type: string;
  role: string;
  comment: string;
}>;
/**
 * Merge a freshly-fetched table meta into an existing table YAML: overwrite
 * `columns` (via `mergeColumns`) when present and always refresh `partitions`.
 * @param existing - the existing table YAML dict.
 * @param newMeta - the freshly-fetched table meta to merge in.
 * @returns a new merged dict (shallow-copy of `existing` with refreshed `columns`/`partitions`).
 */
declare function mergeChangedYaml(existing: Record<string, unknown>, newMeta: TableMeta): Record<string, unknown>;
/**
 * Tier-2 batch sync-write: for each table meta, generate (or merge when an
 * existing entry is supplied) the table YAML and write it via `writeTable`,
 * recording each write through `opts.recorder` (D5 non-disableable audit).
 * Tables are independently fail-tolerant: a thrown write becomes an error
 * string rather than aborting the batch.
 * @param semanticLayer - the semantic-layer directory path.
 * @param tableMetas - the table metas to write (metas with empty `table_name` are skipped).
 * @param opts - the recorder, optional dim-table-name set (generates DIM YAML), and optional existing-table map (merges).
 * @returns counts of `written`/`skipped` plus a per-table `errors` list.
 */
declare function syncWriteDefinitions(semanticLayer: string, tableMetas: readonly TableMeta[], opts: Tier2Opts & {
  readonly dimTableNames?: Set<string>;
  readonly existingTables?: Map<string, Record<string, unknown>>;
}): Promise<{
  written: number;
  skipped: number;
  errors: string[];
}>;
//#endregion
//#region src/enrichment.d.ts
/**
 * A DIM table summarized for relation discovery: its name, primary_key, a
 * description, and (optionally), its columns for richer LLM context.
 */
interface DimInventoryEntry {
  readonly table_name: string;
  readonly primary_key: readonly string[];
  readonly description: string;
  readonly columns?: ReadonlyArray<{
    name: string;
    comment?: string;
    type?: string;
  }>;
}
/**
 * An injectable one-shot text LLM call (prompt in, text out). When omitted,
 * `discoverRelationsFor` runs the deterministic round only. Production wires
 * this to `ctx.llm` (B3/B4); the substrate stays free of the LLM dependency.
 */
type LlmCall = (prompt: string) => Promise<string>;
/**
 * Deterministic round: for each DIM with a non-empty `primary_key`, emit a
 * DimensionRef for every DIM PK column whose name exactly matches a column on
 * the target DWS (G3 exact-name match). High-precision seed set; no LLM.
 *
 * CL-18 Phase 2: an optional `excludeColumns` set (typically the target
 * table's partition columns, e.g. `ds`/`pt`/`dt`) filters out noise JOIN
 * relations — a DIM whose PK is a partition column (e.g. an `_arch` snapshot
 * table keyed by `ds`) would otherwise match every DWS that carries that
 * partition column. The set is computed by the calling layer (see
 * `buildExcludeColumns` in the Service shell) so this substrate stays free of
 * any specific metadata-format assumption.
 * @param targetDef - the DWS table definition to find DIM joins for.
 * @param dimInventory - the DIM tables to match against.
 * @param excludeColumns - optional set of column names to exclude from PK matching (e.g. partition columns).
 * @returns one DimensionRef per DIM whose PK shares at least one non-excluded column name with the target.
 */
declare function discoverRelationsDeterministic(targetDef: TableDefinition, dimInventory: readonly DimInventoryEntry[], excludeColumns?: ReadonlySet<string>): DimensionRef[];
/**
 * Merge two DimensionRef lists: dedupe by `dim_table`, unioning `join_keys`
 * (deduped by the dws|dim pair). The second list's `derivation` (and `origin`)
 * overrides the first's when the added ref has a strictly higher origin
 * priority — i.e. 'llm' overrides 'deterministic', 'manual' overrides both,
 * and `undefined` (legacy / human-curated) is treated as 'manual' (never
 * auto-overridden).
 * @param baseline - the first list (e.g. deterministic refs, or existing curated refs).
 * @param added - the second list (e.g. LLM refs, or newly-discovered refs).
 * @returns the merged, deduped DimensionRef list (baseline preserved + added unioned).
 */
declare function mergeRefs(baseline: readonly DimensionRef[], added: readonly DimensionRef[]): DimensionRef[];
/**
 * Build the LLM prompt for one target DWS: its columns (name + comment) +
 * description, plus the full DIM inventory (table_name + primary_key +
 * description). The model is asked to return a JSON array of DimensionRef.
 * @param targetDef - the DWS table definition.
 * @param dimInventory - the DIM tables to consider.
 * @returns the assembled prompt text.
 */
declare function buildLlmPrompt(targetDef: TableDefinition, dimInventory: readonly DimInventoryEntry[]): string;
/**
 * Parse + validate an LLM's textual response into DimensionRefs. Lenient: any
 * item failing `DimensionRefSchema` (e.g. empty join_keys) is dropped rather
 * than aborting the whole batch.
 * @param text - the raw LLM response text.
 * @returns the valid DimensionRefs found in the response (empty when none/invalid).
 */
declare function parseLlmRefs(text: string): DimensionRef[];
/**
 * Discover dimension relations for one DWS table (G3 two-round strategy).
 * Round 1 (deterministic, no LLM) always runs; round 2 (LLM) runs only when
 * `llmCall` is provided and is best-effort (a thrown call or invalid JSON
 * degrades to round-1 results only).
 *
 * CL-18 Phase 2: `excludeColumns` (optional) is forwarded to the
 * deterministic round to filter out partition-column PK matches (noise JOINs).
 * @param targetDef - the DWS table definition.
 * @param dimInventory - the DIM tables to match against.
 * @param llmCall - optional one-shot LLM call for the semantic round.
 * @param excludeColumns - optional set of column names to exclude from deterministic PK matching.
 * @returns the merged DimensionRefs for the target.
 */
declare function discoverRelationsFor(targetDef: TableDefinition, dimInventory: readonly DimInventoryEntry[], llmCall?: LlmCall, excludeColumns?: ReadonlySet<string>): Promise<DimensionRef[]>;
/**
 * Build the DIM inventory from the layer's DIM tables (kind='dim').
 * @param semanticLayer - the semantic-layer directory path.
 * @returns the DIM inventory entries (table_name + primary_key + description + columns).
 */
declare function buildDimInventory(semanticLayer: string): DimInventoryEntry[];
/**
 * Enrich every DWS table (kind !== 'dim') in a semantic layer: discover its
 * DIM relations and write them back into the table YAML's `dimension_refs`.
 *
 * Writes preserve the raw file verbatim (physical types, extra keys) — only
 * `dimension_refs` is replaced/merged — because `writeTable` writes the passed
 * object after validating it (it does not rewrite canonicalized types). DIM
 * tables are left untouched. Per-table fail-tolerant: a thrown discover/write
 * becomes an error string rather than aborting the batch.
 *
 * `mergeExisting`: when `true`, discovered refs are merged WITH the table's
 * existing `dimension_refs` (everything preserved, discovered unioned) — used by
 * the on-write hook so auto-trigger can never wipe any existing join. When
 * `false` (default), replace: curated existing refs (`manual` / `undefined`)
 * are preserved and machine-generated ones (`deterministic` / `llm`) are
 * dropped so re-discovery can refresh them — used by the explicit
 * `discoverRelations` entry (re-discover, G3 direct-write). By default
 * (`preserveCurated=true`) the replace is origin-aware (GA-GT3 item 5);
 * `preserveCurated=false` is the escape-hatch (GA-GT3-5b) for the rare
 * blow-away-rebuild case: a raw full replace that drops ALL existing refs
 * (incl. curated manual/undefined) and writes only the freshly-discovered set.
 *
 * CL-18 Phase 2: `excludeColumnsFn` (optional) computes a per-target exclude
 * set from the target table's metadata (e.g. its partition columns) and
 * forwards it to `discoverRelationsFor` so partition-column PK matches (e.g.
 * `ds`-only DIM snapshots) do not generate noise JOIN relations. The calling
 * layer supplies this function; the substrate applies it opaquely.
 * @param semanticLayer - the semantic-layer directory path.
 * @param llmCall - optional one-shot LLM call for the semantic round.
 * @param tables - optional table_name filter; omit or empty to enrich all DWS tables.
 * @param mergeExisting - when true, merge discovered refs with existing (preserve curated); default false (replace).
 * @param excludeColumnsFn - optional per-target exclude-set builder (CL-18 Phase 2).
 * @param preserveCurated - when true (default), origin-aware replace (curated
 *   manual/undefined preserved, machine dropped); when false, raw full replace
 *   (ALL existing refs dropped, only discovered remain) — the escape-hatch for
 *   blow-away-rebuild (GA-GT3-5b). Ignored when `mergeExisting=true`.
 * @returns `enriched` (DWS tables that gained at least one ref) + `written` (DWS
 *   tables updated) + per-table `errors`.
 */
declare function enrichAllDwsTables(semanticLayer: string, llmCall?: LlmCall, tables?: readonly string[], mergeExisting?: boolean, excludeColumnsFn?: (def: TableDefinition) => ReadonlySet<string> | undefined, preserveCurated?: boolean): Promise<{
  enriched: number;
  written: number;
  errors: string[];
  note?: string;
}>;
/**
 * Deterministic round for events: for each DIM with a non-empty `primary_key`,
 * emit a DimensionRef for every DIM PK column whose name exactly matches an
 * event `params_fields` key (the event param field is the foreign key).
 *
 * CL-18 Phase 2: an optional `excludeColumns` set filters out noise matches
 * (parallel to `discoverRelationsDeterministic` for DWS tables), so a DIM
 * keyed by a partition column does not match an event param of the same name.
 * @param eventDef - the event definition to find DIM joins for.
 * @param dimInventory - the DIM tables to match against.
 * @param excludeColumns - optional set of field names to exclude from PK matching (CL-18 Phase 2).
 * @returns one DimensionRef per DIM whose PK shares at least one non-excluded param-field name.
 */
declare function discoverEventRelationsDeterministic(eventDef: EventDefinition, dimInventory: readonly DimInventoryEntry[], excludeColumns?: ReadonlySet<string>): DimensionRef[];
/**
 * Build the LLM prompt for one event: its params_fields (name + description) +
 * description, plus the DIM inventory. The model returns a JSON array of
 * DimensionRef (same schema as the DWS round).
 * @param eventDef - the event definition.
 * @param dimInventory - the DIM tables to consider.
 * @returns the assembled prompt text.
 */
declare function buildEventLlmPrompt(eventDef: EventDefinition, dimInventory: readonly DimInventoryEntry[]): string;
/**
 * Discover dimension relations for one event (two-round: deterministic + LLM).
 *
 * CL-18 Phase 2: `excludeColumns` (optional) is forwarded to the
 * deterministic round to filter out partition-column PK matches.
 * @param eventDef - the event definition.
 * @param dimInventory - the DIM tables to match against.
 * @param llmCall - optional one-shot LLM call for the semantic round.
 * @param excludeColumns - optional set of field names to exclude from deterministic PK matching.
 * @returns the merged DimensionRefs for the event.
 */
declare function discoverEventRelationsFor(eventDef: EventDefinition, dimInventory: readonly DimInventoryEntry[], llmCall?: LlmCall, excludeColumns?: ReadonlySet<string>): Promise<DimensionRef[]>;
/**
 * Enrich every event in a semantic layer: discover its DIM relations and write
 * them back into the event YAML's `external_refs`. Mirrors `enrichAllDwsTables`
 * (two-round; deterministic round always runs, LLM round runs only when a
 * `llmCall` is provided). Writes via `writeEventYaml` (raw-edit surface: read
 * the existing raw, inject `external_refs`, re-dump to YAML text, name-match
 * check; no schema validation — `loadEvents` validates on read).
 * `mergeExisting`: when true, discovered refs merge WITH the event's existing
 * `external_refs` (everything preserved, discovered unioned); default false —
 * replace (curated `manual`/`undefined` preserved, machine `deterministic`/`llm`
 * dropped so re-discovery refreshes them; GA-GT3 item 5, parallel to
 * `enrichAllDwsTables`). By default (`preserveCurated=true`) the replace is
 * origin-aware; `preserveCurated=false` is the escape-hatch (GA-GT3-5b) for the
 * rare blow-away-rebuild case: a raw full replace that drops ALL existing refs
 * (incl. curated manual/undefined) and writes only the freshly-discovered set.
 *
 * CL-18 Phase 2: `excludeColumnsFn` (optional) computes a per-event exclude
 * set and forwards it to `discoverEventRelationsFor` (parallel to
 * `enrichAllDwsTables`). The calling layer supplies the builder; the
 * substrate applies it opaquely.
 * @param semanticLayer - the semantic-layer directory path.
 * @param llmCall - optional one-shot LLM call for the semantic round.
 * @param events - optional event-name filter; omit/empty to enrich all events.
 * @param mergeExisting - when true, merge discovered with existing; default false.
 * @param excludeColumnsFn - optional per-event exclude-set builder (CL-18 Phase 2).
 * @param preserveCurated - when true (default), origin-aware replace (curated
 *   manual/undefined preserved, machine dropped); when false, raw full replace
 *   (ALL existing refs dropped, only discovered remain) — the escape-hatch for
 *   blow-away-rebuild (GA-GT3-5b). Ignored when `mergeExisting=true`.
 * @returns `enriched` (events gaining >=1 ref) + `written` (events updated) + per-event `errors`.
 */
declare function enrichAllEvents(semanticLayer: string, llmCall?: LlmCall, events?: readonly string[], mergeExisting?: boolean, excludeColumnsFn?: (def: EventDefinition) => ReadonlySet<string> | undefined, preserveCurated?: boolean): Promise<{
  enriched: number;
  written: number;
  errors: string[];
  note?: string;
}>;
/** A definition summary for alt_labels enrichment (works for both tables and events). */
interface AltLabelsTarget {
  readonly id: string;
  readonly kind: 'table' | 'event';
  readonly description: string;
  readonly domains: readonly string[];
  readonly columns?: ReadonlyArray<{
    name: string;
    comment?: string;
  }>;
  readonly existingAltLabels: readonly string[];
  readonly existingPrefLabel: string | undefined;
}
/**
 * Deterministic round for alt_labels discovery: extract candidate aliases from
 * description, table_comment, column comments, and domains. No LLM needed.
 *
 * Heuristics:
 * - Chinese parenthesized terms in description/table_comment (e.g. "用户活跃度（DAU）" → "DAU")
 * - Quoted terms (single/double quotes, angle brackets) in description
 * - Domain names as-is (they're already business vocabulary)
 *
 * Returns only NEW labels (not already in existingAltLabels or existingPrefLabel).
 * @param target - target
 * @returns the result
 */
declare function discoverAltLabelsDeterministic(target: AltLabelsTarget): string[];
/**
 * Build the LLM prompt for alt_labels discovery on one definition. Asks the
 * model to suggest alternative search labels (Chinese + English abbreviations)
 * based on the definition's description, columns/fields, and domains.
 * @param target - target
 * @returns the result
 */
declare function buildAltLabelsPrompt(target: AltLabelsTarget): string;
/**
 * Parse the LLM response for alt_labels: extract a JSON array of strings.
 * Lenient — invalid items are dropped.
 * @param text - text
 * @returns the result
 */
declare function parseAltLabelsResponse(text: string): string[];
/**
 * Merge new alt_labels into existing ones (dedupe by normalized form).
 * Preserves the order: existing first, then new.
 * @param existing - existing
 * @param added - added
 * @returns the result
 */
declare function mergeAltLabels(existing: readonly string[], added: readonly string[]): string[];
/**
 * Discover alt_labels for one definition (two-round: deterministic + LLM).
 * Returns the candidate labels to ADD (already deduped against existing).
 * @param target - target
 * @param llmCall - llmCall
 * @returns the result
 */
declare function discoverAltLabelsFor(target: AltLabelsTarget, llmCall?: LlmCall): Promise<string[]>;
/**
 * Enrich all tables in a semantic layer with alt_labels: discover aliases and
 * write them back into each table's YAML. Two-round (deterministic + LLM).
 * Merges with existing alt_labels (never removes curated labels).
 *
 * @param semanticLayer - the semantic-layer directory path.
 * @param llmCall - optional LLM call for the semantic round.
 * @param tables - optional table_name filter; omit/empty to enrich all.
 * @returns `enriched` (tables gaining >=1 new label) + `written` + per-table `errors`.
 */
declare function enrichAllTablesAltLabels(semanticLayer: string, llmCall?: LlmCall, tables?: readonly string[]): Promise<{
  enriched: number;
  written: number;
  errors: string[];
}>;
/**
 * Enrich all events in a semantic layer with alt_labels: discover aliases and
 * write them back into each event's YAML. Two-round (deterministic + LLM).
 * Merges with existing alt_labels (never removes curated labels).
 *
 * @param semanticLayer - the semantic-layer directory path.
 * @param llmCall - optional LLM call for the semantic round.
 * @param events - optional event-name filter; omit/empty to enrich all.
 * @returns `enriched` (events gaining >=1 new label) + `written` + per-event `errors`.
 */
declare function enrichAllEventsAltLabels(semanticLayer: string, llmCall?: LlmCall, events?: readonly string[]): Promise<{
  enriched: number;
  written: number;
  errors: string[];
}>;
/**
 * Enrich ALL definitions (tables + events) in a semantic layer with alt_labels.
 * Convenience wrapper: runs `enrichAllTablesAltLabels` + `enrichAllEventsAltLabels`.
 *
 * @param semanticLayer - the semantic-layer directory path.
 * @param llmCall - optional LLM call for the semantic round.
 * @param tables - optional table_name filter (omit to enrich all tables).
 * @param events - optional event-name filter (omit to enrich all events).
 * @returns combined `enriched` + `written` + `errors`.
 */
declare function discoverAltLabels(semanticLayer: string, llmCall?: LlmCall, tables?: readonly string[], events?: readonly string[]): Promise<{
  enriched: number;
  written: number;
  errors: string[];
}>;
//#endregion
//#region src/registry.d.ts
/**
 * DataSourceRegistry — a typed plugin registry for semantic-layer data-source
 * kinds (G1 Decision B: DataSourceKindPlugin<T>). Each kind plugin declares how
 * to identify, index, format, and relate definitions of its type.
 *
 * Aligned with G1 §D2 interface design + G2 ontology decisions.
 *
 * @module registry (internal; only `"."` is importable — see ADR-0002)
 */
/** A unified corpus item for retrieval indexing (G1: type-agnostic). */
interface CorpusItem {
  readonly id: string;
  readonly description?: string;
  readonly metrics?: Readonly<Record<string, unknown>>;
  readonly payload?: unknown;
}
/**
 * Aggregated critic-context fields from one or more definitions (G1 §D2).
 * Fields are optional — not all kinds provide all axes.
 */
interface CriticFields {
  readonly eventParams?: Readonly<Record<string, unknown>>;
  readonly partitionCols?: readonly string[];
}
/**
 * A relation declared by a data source (G1 §D2 + G2: three base types, OPEN).
 * Returned by plugin.relations(def); source is the definition that declared it.
 *
 * `type` is an open `string` (W27): the three base kinds (`joins`,
 * `derived_from`, `related_to`) cover the built-in kinds, but a kind
 * registered later may declare its own relation kind (e.g. `visualizes`)
 * without editing this union. The RelationGraph + Schema Gateway carry the
 * open `type` through to the client without a per-type switch.
 */
interface RelationDef {
  /** Open relation kind — `joins` | `derived_from` | `related_to` or a kind-declared type. */
  readonly type: string;
  /**
   * The canonical node id of the target data source — exactly the `id` its
   * owning kind mints in {@link DataSourceKindPlugin.toGraphNode}, including
   * any namespace prefix (`concept:sales`, not `sales`). The graph build stores
   * it verbatim: nothing maps a bare name onto a prefixed id, because two kinds
   * may hold a node of the same name and any such mapping would silently route
   * the edge to the wrong one. A target naming no projected node yields no
   * edge in the Schema Gateway projection rather than an error.
   */
  readonly target: string;
  /** Join condition expression (e.g. "charm_id = charm_id"). */
  readonly on?: string;
  /** Human-readable description of the relationship. */
  readonly description?: string;
}
/**
 * A data source projected as one graph node (W27). Plain `string` id + open
 * `kind` — the Semantic Layer has no notion of cross-process branding; the
 * Schema Gateway brands `id` when it assembles the Remote `SemanticGraphNode`
 * at the wire boundary. Returned by `DataSourceKindPlugin.toGraphNode`.
 */
interface GraphNodeProjection {
  /** Node identity (table_name, event name, `metric` name, or `concept:<name>`). */
  readonly id: string;
  /** Open node kind (a client presentation key, never a closed union). */
  readonly kind: string;
  /** Display label. */
  readonly label: string;
  /** Domain(s)/group(s) the node belongs to. */
  readonly domains: readonly string[];
}
/**
 * Virtual definitions a kind derives from each of its own definitions, and how
 * to project them (W27). Declared by the kind so nothing in the projection
 * branches on a kind string: a kind registered later contributes derived nodes
 * the same way the built-ins do. `metric` is the shipped case — the `table` and
 * `event` kinds each derive one metric per inline `metrics:` entry.
 *
 * A derived definition is projected, related, and indexed exactly like a stored
 * one, including the canonical-id rule on {@link RelationDef.target}.
 */
interface DerivedNodeContributor<T = unknown, D = unknown> {
  /** Derive one definition's virtual definitions; empty when it has none. */
  derive(def: T): readonly D[];
  /** Project one derived definition as a graph node, or `null` to keep it out of the graph. */
  toGraphNode(derived: D): GraphNodeProjection | null;
  /** Relations one derived definition declares; empty array when it declares none. */
  relations(derived: D): RelationDef[];
  /** Corpus item for one derived definition, or `null` to skip retrieval indexing. */
  toCorpusItem(derived: D): CorpusItem | null;
}
/**
 * Declares a kind whose nodes are taxonomy groups (W27): each node of this kind
 * names a group that nodes of OTHER kinds join by listing that name in
 * {@link GraphNodeProjection.domains}. The graph build derives one
 * group→member edge per resolved name and reports unresolved names through
 * `SemanticGroundingCore.getDanglingDomainRefs()` instead of aborting the build.
 *
 * A grouping node's own `domains` carry its group name, so nodes of a grouping
 * kind contribute no member references of their own — that would be a self-loop.
 * `concept` is the shipped case.
 */
interface KindGrouping {
  /** The group name one node of this kind defines (`concept:sales` → `sales`). */
  groupName(node: GraphNodeProjection): string;
  /** Relation type of each derived group→member edge. */
  readonly memberRelationType: string;
}
/** Minimal schema interface (structurally matches zod schemas without hard dep). */
interface SchemaLike<T> {
  parse(raw: unknown): T;
  safeParse(raw: unknown): {
    success: boolean;
    data?: T;
    error?: unknown;
  };
}
/**
 * A plugin that teaches the registry how to handle one kind of data source.
 * Generic over T (the definition shape — EventDefinition, TableDefinition, etc.).
 * G1 §D2 aligned: schema, terminology-aware toCorpusItem, raw-based getId.
 */
interface DataSourceKindPlugin<T = unknown> {
  /** Unique kind identifier (e.g. 'event', 'table', 'metric'). */
  readonly kind: string;
  /** Zod validation schema for this kind's definitions (G1 §D2). */
  readonly schema: SchemaLike<T>;
  /** YAML storage subdirectory name (e.g. 'events', 'tables', 'metrics'). */
  readonly storageDir: string;
  /**
   * Extract the canonical id from a raw (unparsed) YAML object (G1 §D2).
   * Returns undefined if the raw object doesn't have a valid id for this kind.
   */
  getId(raw: Record<string, unknown>): string | undefined;
  /**
   * Project a definition to a corpus item for retrieval indexing (G1 §D2).
   * Returns null to skip indexing for this definition.
   */
  toCorpusItem(def: T): CorpusItem | null;
  /** Format a definition into prompt context (for model-facing tools). */
  toPromptContext(def: T): string;
  /** Extract critic-relevant fields from a definition (optional; not all kinds have critic logic). */
  toCriticContext?(def: T): CriticFields;
  /**
   * Declare relations this definition has to other data sources (G2: required).
   * Return empty array when no relations exist.
   */
  relations(def: T): RelationDef[];
  /**
   * Project a definition to one semantic-graph node (W27), or `null` to declare
   * this definition is not a graph node. Each kind decides its own node id,
   * open `kind` string, label, and domains; the Schema Gateway iterates every
   * registered kind's `toGraphNode` to build the graph (no hand-written
   * per-kind loops), so a kind registered later reaches the graph without
   * editing the gateway.
   */
  toGraphNode(def: T): GraphNodeProjection | null;
  /**
   * Virtual definitions this kind derives from each of its own definitions
   * (W27). Omit when the kind derives nothing.
   */
  readonly derivedNodes?: DerivedNodeContributor<T>;
  /**
   * Declares this kind's nodes as taxonomy groups other kinds join through
   * `GraphNodeProjection.domains` (W27). Omit for an ordinary asset kind.
   */
  readonly grouping?: KindGrouping;
  /**
   * Return an executable rule/SQL template (G2, MetricPlugin only — removed in M1b; retained as optional interface for backward-compat).
   * Optional — only metric-type plugins implement this.
   */
  toExecutableRule?(def: T): string | null;
}
/**
 * Registry of data-source kind plugins. Allows registration and lookup by kind string.
 */
declare class DataSourceRegistry {
  private readonly plugins;
  private readonly changeListeners;
  /**
   * Register a listener invoked when a kind is added or removed. The
   * SemanticGroundingCore wires this to invalidate its relation-graph cache so
   * a disposed kind's nodes/edges do not linger (W27: disposer + cache
   * invalidation). Returns a disposer for this listener.
   * @param listener - a no-arg callback fired after a kind is added or removed.
   * @returns a disposer that removes this listener.
   */
  onChange(listener: () => void): () => void;
  /**
   * Register a kind plugin. Throws if the kind is already registered.
   * Install with `ctx.effect(() => registry.register(plugin))` so the
   * contribution's lifetime tracks the owning fiber.
   * @param plugin - the kind contribution.
   * @returns an idempotent disposer that removes only this registration and
   *  fires change listeners so cached projections (e.g. the relation graph)
   *  rebuild without the disposed kind.
   */
  register(plugin: DataSourceKindPlugin): () => void;
  /**
   *  Get a registered plugin by kind, or undefined if not registered.
   * @param kind - kind
   * @returns the result
   */
  getKind(kind: string): DataSourceKindPlugin | undefined;
  /**
   *  Return all registered kind strings.
   * @returns the result
   */
  allKinds(): string[];
  /**
   *  Return all registered plugins.
   * @returns the result
   */
  allPlugins(): DataSourceKindPlugin[];
}
//#endregion
//#region src/relation-graph.d.ts
/** An edge in the relation graph (stored in adjacency list per node). */
interface RelationEdge {
  readonly targetId: string;
  /** Open relation kind (W27: `joins` | `derived_from` | `related_to` or a kind-declared type). */
  readonly type: string;
  readonly on?: string;
  readonly description?: string;
}
/** Alias data for a single node (pref_label + alt_labels from the definition). */
interface NodeAliasData {
  readonly nodeId: string;
  readonly prefLabel?: string | undefined;
  readonly altLabels?: readonly string[] | undefined;
}
/**
 * In-memory relation graph. Builds a bidirectional adjacency list from
 * RelationDef entries (plugin.relations() output + source id).
 * CL-1 Phase 2: also builds a reverse alias index from SKOS labels.
 */
declare class RelationGraph {
  private adj;
  private aliasIndex;
  private nodeAliases;
  /**
   * Build the graph from source-tagged relation declarations and optional alias data.
   * Clears existing state. Stores bidirectional edges for traversal.
   * When aliasData is provided, builds the reverse alias index (normalized_alias → nodeIds).
   * @param entries - entries
   * @param aliasData - aliasData
   */
  build(entries: {
    sourceId: string;
    relations: RelationDef[];
  }[], aliasData?: readonly NodeAliasData[]): void;
  private addEdge;
  /**
   * BFS shortest path over 'joins'-type edges only.
   * Returns the node-id path [source, ..., target] or null if unreachable.
   * @param sourceId - sourceId
   * @param targetId - targetId
   * @returns the result
   */
  findJoinPath(sourceId: string, targetId: string): string[] | null;
  /**
   * Get directly related node ids (optionally filtered by relation type).
   * @param sourceId - sourceId
   * @param type - open relation kind to filter by (e.g. `joins`); omit for all.
   * @returns the result
   */
  getRelated(sourceId: string, type?: string): RelationEdge[];
  /**
   * Get the join condition between two directly connected nodes, or null.
   * @param sourceId - sourceId
   * @param targetId - targetId
   * @returns the result
   */
  getJoinCondition(sourceId: string, targetId: string): string | null;
  /**
   * Get the derived-from chain: all nodes reachable via 'derived_from' edges
   * from the given source (G2 lineage traversal).
   * @param sourceId - sourceId
   * @returns the result
   */
  getDerived(sourceId: string): RelationEdge[];
  /**
   * Resolve a term to node ids via the alias index. Normalizes the input
   * and looks up the reverse index (normalized_alias → nodeIds).
   * Returns an empty array when no match is found.
   * @param term - term
   * @returns the result
   */
  resolveAlias(term: string): string[];
  /**
   * Get all aliases (pref_label + alt_labels) registered for a node.
   * Returns an empty array when the node has no aliases.
   * @param nodeId - nodeId
   * @returns the result
   */
  getAliases(nodeId: string): string[];
}
//#endregion
//#region src/snapshot.d.ts
/**
 * A frozen point-in-time view of semantic layer definitions. Provides the same
 * read-only API surface as `SemanticGroundingCore` but the data is pinned at
 * the version captured when the snapshot was acquired — subsequent
 * `invalidateCaches()` calls do not affect it.
 */
declare class DefinitionSnapshot {
  /** The corpus version at the time this snapshot was captured. */
  readonly version: number;
  private readonly _tables;
  private readonly _events;
  private readonly _corpus;
  /** Lazily populated table-definition cache (by table_name). */
  private _tableDefCache;
  /** Lazily populated event-definition cache (by name). */
  private _eventDefCache;
  constructor(version: number, tables: readonly RawTable[], events: readonly RawEvent[], corpus: readonly EventCorpusItem[]);
  /**
   * Load a validated table definition by name from the snapshot.
   * @param name - the table `table_name` key to match.
   * @returns the parsed `TableDefinition`, or null when no table matches.
   */
  loadTableDefinition(name: string): TableDefinition | null;
  /**
   * Load a validated event definition by name from the snapshot.
   * @param name - the event `name` key to match.
   * @returns the parsed `EventDefinition`, or null when no event matches.
   */
  loadEventDefinition(name: string): EventDefinition | null;
  /**
   * Load a validated metric definition by name from the snapshot.
   * @param name - the metric `name` key to match (`<host>__<key>`).
   * @returns the parsed `MetricDefinition`, or null when no host defines it.
   */
  loadMetricDefinition(name: string): MetricDefinition | null;
  /**
   * The enriched retrieval corpus captured at snapshot time (events only,
   * D2e-compatible). Pinned — not affected by subsequent writes.
   * @returns the frozen corpus items.
   */
  loadRetrievalCorpus(): readonly EventCorpusItem[];
  /**
   * All raw tables captured in this snapshot.
   * @returns the frozen table list (unvalidated raw dicts).
   */
  get tables(): readonly RawTable[];
  /**
   * All raw events captured in this snapshot.
   * @returns the frozen event list (unvalidated raw dicts).
   */
  get events(): readonly RawEvent[];
}
/** Upper bound on the number of distinct semanticRoots the module-level
 * snapshot cache retains. The cache is version-keyed and self-invalidating
 * per root, but an unbounded set of distinct roots (one per scope) could grow
 * without limit; this cap evicts the oldest entry (FIFO — Map preserves
 * insertion order) when exceeded. Present-root cache-hit semantics are
 * unchanged: a hit returns early (no eviction), so an actively-cached root is
 * never displaced by a re-capture of itself. */
declare const SNAPSHOT_CACHE_MAX = 64;
/**
 * Capture a `DefinitionSnapshot` for the given semantic-layer root. If the
 * corpus version has not changed since the last capture for this root, the
 * cached data arrays are reused (no disk re-scan).
 *
 * @param semanticRoot - the semantic-layer directory path.
 * @param serviceVersion - the service-level corpus version (includes scope epoch).
 * @param corpusVariant - the enrichment variant for the retrieval corpus.
 * @returns a fresh `DefinitionSnapshot` pinned at the current version.
 */
declare function captureSnapshot(semanticRoot: string, serviceVersion: number, corpusVariant?: CorpusVariant): DefinitionSnapshot;
/**
 * Clear the module-level snapshot cache (for testing). Production code does
 * not need this — the cache is version-keyed and self-invalidating.
 */
declare function clearSnapshotCache(): void;
/**
 * The current number of cached snapshot entries (distinct semanticRoots).
 * Exported for test/health observation of the bounded cache (mirrors
 * `clearSnapshotCache`); production code does not need this — the cache is
 * version-keyed and self-invalidating per root.
 * @returns the number of entries currently in the module-level cache.
 */
declare function getSnapshotCacheSize(): number;
//#endregion
//#region src/basic-index.d.ts
/** A raw event YAML dict plus the domain subdir it was scanned from (no validation at build). */
interface EventIndexEntry {
  readonly raw: Record<string, unknown>;
  readonly domain: string;
}
/** A raw table YAML dict plus the file path it was scanned from (no validation at build). */
interface TableIndexEntry {
  readonly path: string;
  readonly raw: Record<string, unknown>;
}
/** Dep-free lookup accelerator over a semantic-layer scope dir. */
declare class BasicIndex {
  private readonly semanticLayer;
  private _dirty;
  private _events;
  private _tables;
  private _domains;
  /** ADR-0011: disposer for this index's invalidation hook (call `dispose()` to remove it). */
  private readonly _disposeHook;
  constructor(semanticLayer: string);
  /** Remove this index's invalidation hook (call when the index is no longer used). */
  dispose(): void;
  private _build;
  private _ensure;
  /**
   * Look up a single event by name, returning its raw dict + domain.
   * @param name - the event `name` key to match.
   * @returns the matching event entry, or null when the name is not indexed.
   */
  lookupEvent(name: string): EventIndexEntry | null;
  /**
   * Look up a single table by name, returning its raw dict + path.
   * @param name - the table `table_name` key to match.
   * @returns the matching table entry, or null when the name is not indexed.
   */
  lookupTable(name: string): TableIndexEntry | null;
  /**
   * Count indexed events (triggers a rebuild when dirty).
   * @returns the number of events in the layer.
   */
  eventCount(): number;
  /**
   * Count indexed tables (triggers a rebuild when dirty).
   * @returns the number of tables in the layer.
   */
  tableCount(): number;
  /**
   * Count indexed tables whose `kind` matches (defaults to `dws` when absent).
   * @param kind - the kind value to count (`dws` or `dim`).
   * @returns the number of tables whose kind equals `kind`.
   */
  tableCountByKind(kind: string): number;
  /**
   * Enumerate every indexed event with its name merged into the entry.
   * @returns a fresh array of all event entries (name + raw + domain).
   */
  events(): Array<{
    name: string;
  } & EventIndexEntry>;
  /**
   * Enumerate every indexed table entry.
   * @returns a fresh array of all table entries (path + raw).
   */
  tableEntries(): TableIndexEntry[];
  /**
   * Return the parsed `domains.yaml` catalog (empty object when absent).
   * @returns the domains catalog map, or `{}` when the file is missing/malformed.
   */
  domainsCatalog(): Record<string, unknown>;
}
//#endregion
//#region src/pending.d.ts
/** A queued Tier-1 self-modification suggestion (one JSON file in the pending `var/` queue). */
interface PendingSuggestion {
  readonly suggestion_id: string;
  readonly kind: string;
  readonly subject: string;
  readonly content: string;
  readonly submitted_at: string;
  readonly scope_id: string | null;
  readonly tenant_id: string | null;
  readonly meta: Record<string, unknown>;
}
/**
 * Validate a suggestion id against the path-traversal-safe format (timestamp + 8-hex short hash + 4-hex nonce).
 * @param id - the candidate id (null/undefined treated as empty string).
 * @returns true when the id matches `^[0-9]{8}T[0-9]{6}Z_[0-9a-f]{8}_[0-9a-f]{4}$`.
 */
declare function isValidId(id: string | undefined | null): boolean;
/** Arguments for submitting a Tier-1 suggestion (kind/subject/content + optional scope/tenant/meta). */
interface SubmitArgs {
  readonly kind: string;
  readonly subject: string;
  readonly content: string;
  readonly scope_id?: string | null;
  readonly tenant_id?: string | null;
  readonly meta?: Record<string, unknown>;
}
/**
 * Submit a Tier-1 suggestion to the pending queue (does NOT touch source-of-truth).
 * @param root - the pending-queue directory path (created when missing).
 * @param args - the suggestion payload (kind/subject/content + optional scope/tenant/meta).
 * @returns the persisted suggestion (with a generated `suggestion_id` + ISO `submitted_at`).
 */
declare function submit(root: string, args: SubmitArgs): PendingSuggestion;
/**
 * Load a pending suggestion by id (invalid/missing/corrupt => null).
 * @param root - the pending-queue directory path.
 * @param suggestion_id - the suggestion id to load (rejected by `isValidId` => null).
 * @returns the parsed suggestion, or null when the id is invalid, the file is missing, or JSON parse fails.
 */
declare function load(root: string, suggestion_id: string): PendingSuggestion | null;
/**
 * List all pending suggestions, oldest first.
 * @param root - the pending-queue directory path (returns `[]` when the dir is missing).
 * @returns every readable suggestion sorted by `submitted_at` ascending.
 */
declare function listing(root: string): PendingSuggestion[];
/**
 * Discard a pending suggestion from the queue (approve consumes the queue).
 * @param root - the pending-queue directory path.
 * @param suggestion_id - the suggestion id to discard (rejected by `isValidId` => false).
 * @returns true when the file was unlinked, or false when the id is invalid or the file is missing.
 */
declare function discard(root: string, suggestion_id: string): boolean;
//#endregion
//#region src/metrics.d.ts
/**
 * Infer the aggregation verb + field from a metric expression (best-effort).
 * `SUM(pay_amt)` → `{ aggregation: 'sum', field: 'pay_amt' }`; `COUNT(*)` →
 * `{ aggregation: 'count', field: '*' }`; `COUNT(DISTINCT user_id)` →
 * `{ aggregation: 'count_distinct', field: 'user_id' }`. Unknown expressions
 * yield empty strings (the expression is still preserved in `computation.sql`).
 * @param expression - the metric expression (e.g. `SUM(pay_amt)`).
 * @returns the inferred aggregation verb + field (empty when not inferable).
 */
declare function inferAggregation(expression: string): {
  aggregation: string;
  field: string;
};
/**
 * Build the unique metric name for one (source, metric-key) pair, namespaced
 * `<source>__<key>` so shared keys (e.g. `row_count`) do not collide across
 * the 321 tables.
 * @param source - the table/event name the metric was extracted from.
 * @param key - the metric key in the source's `metrics:` record.
 * @returns the namespaced metric name.
 */
declare function metricName(source: string, key: string): string;
/**
 * Split a namespaced metric name (`<source>__<key>`, as built by {@link metricName})
 * back into its host source + key. Splits on the LAST `__` so a source or key
 * that itself contains `__` is handled (the trailing segment is the key).
 * Returns null when the name has no `__` separator or it sits at the start
 * (no host). The inverse of {@link metricName}.
 *
 * Used by `SemanticLayerService.loadMetricDefinition` and
 * `DefinitionSnapshot.loadMetricDefinition` to recover the host + key from a
 * metric name and look the key up in the host's inline `metrics:` block (M1
 * virtual projection — no standalone `metrics/*.yaml` files are read).
 * @param name - the namespaced metric name.
 * @returns `{ host, key }` or null when the name is not a `<host>__<key>` pair.
 */
declare function splitMetricName(name: string): {
  host: string;
  key: string;
} | null;
/**
 * Convert one inline MetricDef (from a table/event `metrics:` block) into a
 * standalone MetricDefinition. `expression` → `computation.sql`,
 * `source` → `computation.metadata.source`, and a `derived_from` relation to
 * the source is auto-established (B5 "自动建立 derived_from 关系").
 *
 * Carries the host block's `caliber_variants` onto the derived metric so the
 * planner retains its Type B disambiguation signal (M1c: restores signal lost
 * when metrics were flattened to standalone YAMLs).
 * @param source - the table/event name the metric was extracted from.
 * @param key - the metric key in the source's `metrics:` record.
 * @param def - the inline metric definition (expression + description + caliber_variants).
 * @param domains - the source's domains, copied onto the metric.
 * @returns a MetricDefinition (kind=metric) ready for virtual projection.
 */
declare function toMetricDefinition(source: string, key: string, def: MetricDef, domains: readonly string[]): MetricDefinition;
/**
 *  Project a derived MetricDefinition to a kind:metric CorpusItem for BM25 indexing.
 * @param def - def
 * @returns the result
 */
declare function projectMetricCorpusItem(def: MetricDefinition): {
  id: string;
  description?: string;
  payload: MetricDefinition;
};
/**
 *  Derive relation edges for a metric (derived_from → source; plus any explicit).
 * @param def - def
 * @returns the result
 */
declare function deriveMetricRelations(def: MetricDefinition): {
  type: 'joins' | 'derived_from' | 'related_to';
  target: string;
  on?: string;
  description?: string;
}[];
/**
 * Extract MetricDefinitions from one parsed table definition (one per
 * `metrics:` entry). Pure: no I/O.
 * @param def - the parsed table definition.
 * @returns a MetricDefinition per `metrics:` entry (empty when none).
 */
declare function extractMetricsFromTable(def: TableDefinition): MetricDefinition[];
/**
 * Extract MetricDefinitions from one parsed event definition (one per
 * `metrics:` entry). Pure: no I/O.
 * @param def - the parsed event definition.
 * @returns a MetricDefinition per `metrics:` entry (empty when none).
 */
declare function extractMetricsFromEvent(def: EventDefinition): MetricDefinition[];
/**
 * Extract all MetricDefinitions from a semantic layer: every table's +
 * event's `metrics:` blocks. Pure: returns the definitions, does not write.
 * Lenient: tables/events that fail schema parse are skipped (mirrors the
 * lenient `loadTables`/`loadEvents` scans).
 * @param semanticLayer - the semantic-layer directory path.
 * @returns every extracted MetricDefinition (one per `metrics:` entry).
 */
declare function extractMetricsFromTables(semanticLayer: string): MetricDefinition[];
/**
 * Derive every metric definition at retrieval time from the semantic layer's
 * table + event `metrics:` blocks (M1 virtual projection — no standalone
 * `metrics/*.yaml` files are read). Each inline `metrics:` entry becomes one
 * MetricDefinition via {@link extractMetricsFromTables}. Pure derivation
 * (mechanical, deterministic) replaces the prior read-from-disk scan.
 * @param semanticLayer - the semantic-layer directory path.
 * @returns the derived MetricDefinitions (empty when no table/event has metrics).
 */
declare function loadMetricDefinitions(semanticLayer: string): MetricDefinition[];
/**
 * Project one derived metric as a `metric` graph node (W27). `metric` is not a
 * registered kind — metrics are virtual, derived from host table/event
 * `metrics:` blocks — so the `table` and `event` kinds reach the graph with
 * them through their declared `derivedNodes` contributor, which uses this as
 * its `toGraphNode`.
 * @param def - a derived metric definition.
 * @returns the `metric`-kind graph node for that metric.
 */
declare function metricGraphNode(def: MetricDefinition): GraphNodeProjection;
//#endregion
//#region src/kinds/table-kind.d.ts
/** tableKindPlugin */
declare const tableKindPlugin: DataSourceKindPlugin<TableDefinition>;
//#endregion
//#region src/kinds/event-kind.d.ts
/** eventKindPlugin */
declare const eventKindPlugin: DataSourceKindPlugin<EventDefinition>;
//#endregion
//#region src/kinds/concept-kind.d.ts
/** conceptKindPlugin */
declare const conceptKindPlugin: DataSourceKindPlugin<ConceptDefinition>;
//#endregion
//#region src/index.d.ts
/** Live-engine schema source: discover/describe/sample tables for sync-write (P6b Q3 deferred; production mounts a real provider). */
interface SchemaProvider {
  /** List tables in a scope (optionally filtered by kind). Real impl: maxc list + per-table describe. */
  discover(scopeId: string, kind?: string): Promise<readonly TableMeta[]>;
  /** Describe one table's columns/partitions/comment. */
  describe(tableName: string): Promise<TableMeta | null>;
  /** Sample N rows as formatted text. */
  sample(tableName: string, n?: number): Promise<string>;
}
/** Optional per-scope registry probed via `ctx.get('scopes')` (undefined when unmounted). */
interface ScopeRegistryLike {
  /** The active scope definition, or undefined when no scope is active. */
  active(): {
    readonly id: string;
    readonly semanticRoot: string;
  } | undefined;
  /** The active scope id, or undefined when no scope is active. */
  activeId(): string | undefined;
  /** GA-GT1 Phase 2: resolve a scope by id for per-request scope (undefined when not found). */
  get(id: string): {
    readonly id: string;
    readonly semanticRoot: string;
  } | undefined;
}
/** Which deterministic+semantic enrichment round a health record came from. */
type EnrichmentRound = 'relation' | 'alt_labels';
/** One failed (or partially failed) on-write enrichment round. */
interface EnrichmentHealthEntry {
  /** The round that did not fully succeed. */
  readonly round: EnrichmentRound;
  /** `'partial'` — the round ran and some tables failed; `'failed'` — the whole round threw. */
  readonly outcome: 'partial' | 'failed';
  /** The `table_name`s the round was asked to enrich. */
  readonly tables: readonly string[];
  /** Per-table error messages (`'partial'`), or the single thrown message (`'failed'`). */
  readonly errors: readonly string[];
}
/**
 * CL-18 Phase 2: build the partition-column exclude set for a target table.
 *
 * Strategy (layered, per the ticket design):
 *  - **Data-driven (preferred)**: when the table has columns tagged
 *    `role: 'partition'`, those names form the exclude set. This is the
 *    high-precision path — it excludes exactly the partition columns the
 *    analyst declared for THIS table, including any custom partition names
 *    beyond `ds`/`pt`/`dt`.
 *  - **Fallback blocklist**: when the table has NO `role: 'partition'`
 *    columns (e.g. a sync-written table whose partition columns live in the
 *    separate `partitions` array rather than `columns`, or an unannotated
 *    dataset), fall back to the minimal `DEFAULT_PARTITION_BLOCKLIST`
 *    (`ds`/`pt`/`dt`). This still filters the common noise without depending
 *    on metadata annotations.
 *
 * The result is forwarded into `discoverRelationsFor` via
 * `enrichAllDwsTables`'s `excludeColumnsFn` so the deterministic PK match
 * skips partition columns (e.g. an `_arch` DIM snapshot keyed by `ds` no
 * longer matches every DWS carrying a `ds` column).
 * @param def - the target table definition.
 * @returns a set of column names to exclude from deterministic PK matching (never empty).
 */
declare function buildExcludeColumns(def: TableDefinition): Set<string>;
/** Configuration for the `ctx.schema` Cordis Service (semantic-layer root + default scope id). */
interface SemanticLayerConfig {
  /** Semantic-layer scope root (the dir with config.yaml/events/tables). */
  readonly semanticRoot?: string;
  /** Default scope id for Tier-2 audit + schema discovery. */
  readonly scopeId?: string;
  /** D2h: enrichment variant — 'params+term' (default, D2e-shipped) or
   * 'term-only' (D2g verdict (A) higher-recall). Mount-time config; switching
   * it remounts the Service (new WeakMap key -> fresh enriched linker), so it
   * is NOT part of the D2f corpusVersion cache key. */
  readonly corpusVariant?: CorpusVariant;
  /** G3: auto-run DWS→DIM relation discovery after a Service write
   * (syncWrite/updateTableMeta). Default true (G3: core capability, not an
   * optional hook). Set false to suppress (e.g. during bulk sync). */
  readonly autoEnrich?: boolean;
}
/** Resolved config: all cfg defaults applied ONCE in the constructor into a
 * typed object with REQUIRED fields (Cordis CONVENTIONS.md "no hardcoded
 * tunables" + "defaulting is an explicit `resolve(request): Spec` step, never
 * a hidden `?? default` inside run()"). Use sites read resolved fields — no
 * inline `?? default` tunables scattered across the implementation. Mirrors
 * the `resolveEnrichmentLlmConfig` pattern that moved out with the shell in
 * slice 4a (now in the dsh adapter). */
interface ResolvedSemanticLayerConfig {
  /** Semantic-layer scope root (the dir with config.yaml/events/tables); '' when unset. */
  readonly semanticRoot: string;
  /** Default scope id for Tier-2 audit + schema discovery; '' when unset. */
  readonly scopeId: string;
  /** D2h enrichment variant — 'params+term' (default, D2e-shipped) or 'term-only'. */
  readonly corpusVariant: CorpusVariant;
  /** G3 auto-run DWS→DIM relation discovery after a Service write. Default true. */
  readonly autoEnrich: boolean;
}
/**
 * The semantic grounding core — a plain class with no host framework.
 *
 * Gives a text-to-SQL agent a typed, structured understanding of a data domain:
 * substrate definitions (load_*, sync-read), the relation graph and retrieval
 * corpus projections, provenance-carrying enrichment, and Tier-2 persistent
 * writes. Live-engine schema access (discover/describe/sample) is delegated to
 * an injectable `SchemaProvider` (P6b Q3 deferred).
 *
 * **Embedding.** Construct it, then wire the collaborators the host can supply.
 * Every seam is a setter; none is looked up by name:
 *
 * ```ts
 * const core = new SemanticGroundingCore({ semanticRoot, scopeId })
 * core.setTier2Recorder(recorder)    // REQUIRED before any auditable write (D5)
 * core.setScopeRegistry(scopes)      // optional — falls back to static config
 * core.setSchemaProvider(provider)   // optional — discover/describe/sample throw without one
 * core.setLlmCall(fn)                // optional — enrichment runs deterministic-only without one
 * // ...
 * core.dispose()                     // releases the kind registrations + cache listener
 * ```
 *
 * Nothing above is cordis-specific, and the class imports no host framework
 * (slice 2 ③, map #1). A host adapts it by wrapping, not by being reached for:
 * the dsh adapter wraps this as a cordis `Service` exposing the `ctx.schema`
 * seam and forwards `ctx.audit` / `ctx.get('scopes')` into the setters above.
 *
 * Instances are independent — the recorder, scope registry, provider and LLM
 * call are per-instance state — so one process can hold several cores over
 * different corpora (the MCP management-surface case, which the former
 * `extends Service` made impossible: a cordis context admits only one service
 * under a given name).
 */
declare class SemanticGroundingCore {
  private readonly resolved;
  private provider;
  /** G3: injected one-shot LLM call for the semantic relation round (undefined => deterministic round only). */
  private llmCall;
  /** P1: setter-injected per-scope registry (undefined => fall back to static mount config). */
  private scopeRegistry;
  /** D5: setter-injected Tier-2 recorder. Undefined is NOT "audit off" — every
   * auditable mutation throws until one is wired (ADR-0001). */
  private tier2Recorder;
  private readonly registry;
  /** Disposers owned by this instance (registry listener + built-in kinds), released by `dispose()`. */
  private readonly disposers;
  /** Health records from the most recent on-write enrichment run (reset per run). */
  private enrichmentHealth;
  /** P1: strictly-monotonic counter bumped when the active scope id changes
   * (detected lazily in corpusVersion() — no event listener, so the constructor
   * has no ctx side-effect and test stand-ins without ctx.on still construct).
   * Combined into corpusVersion() so the value changes on every scope switch —
   * including switch-BACK, where the new scope's per-path counter can otherwise
   * collide with the cached version and serve the wrong scope's corpus (the
   * silent semantic-layer leak tool-search-data-sources would otherwise hit). */
  private scopeEpoch;
  /** P1: the active scope id seen at the last corpusVersion() call. Drives lazy
   * switch-detection (undefined until the first call). */
  private lastScopeId;
  /** P1: false until the first corpusVersion() call, so the first call records
   * the id without bumping (an unmounted scope-registry thus keeps epoch=0 =
   * unchanged pre-P1 behavior). */
  private hasObservedScope;
  constructor(config: SemanticLayerConfig);
  /**
   * Release everything this instance registered: the relation-graph
   * cache-invalidation listener and the three built-in kind registrations.
   * Idempotent — a second call is a no-op.
   *
   * This replaces the `ctx.effect(...)` wrapping the registrations used to
   * carry (slice 2 ②). The behavioural guarantee is unchanged — after disposal
   * the registry holds no kinds — but the trigger moves from a host fiber
   * unloading to an explicit call, so the host owns the lifecycle boundary.
   *
   * A host that embeds the core per request/tenant MUST call this; the
   * module-level `registerInvalidationHook` list in `io.ts` is global, so a
   * leaked instance leaks a hook (see the map's Not-yet-specified).
   */
  dispose(): void;
  /**
   * P1: the optional scope-registry, probed by name (undefined when unmounted).
   *
   * Fail-loud: a corrupt `scopes.yaml` makes the registry's `load()` throw a
   * YAMLException, which propagates through `corpusVersion()` rather than
   * silently falling back to static config — a silent fallback could serve the
   * wrong scope's corpus (the exact leak this change prevents). The registry
   * writes atomically, so self-corruption is impossible; only external
   * tampering/disk failure trips this, and failing visibly is the
   * intranet-security-first choice. Locked by the corrupt-yaml test below.
   */
  private scopes;
  /**
   * P1: inject (or clear) the per-scope registry. When absent, `semanticRoot`
   * and `scopeId` fall back to this instance's static mount config.
   *
   * Setter-injected rather than looked up by name (slice 2 ② replaced
   * `ctx.get('scopes')`): the registry is a *collaborator* of the core, so the
   * wiring is visible at the call site instead of depending on whether some
   * host happened to mount a service under the string `'scopes'`.
   * @param registry - the scope registry to delegate to, or undefined to clear.
   */
  setScopeRegistry(registry: ScopeRegistryLike | undefined): void;
  /**
   * GA-GT1 Phase 2: resolve the semanticRoot for a (optional) scopeId.
   *  - scopeId undefined → active scope's root (current behavior; backward-compatible).
   *  - scopeId provided + registry mounted + scope found → that scope's root.
   *  - scopeId provided + registry mounted + scope NOT found → throw
   *    (intranet-security: refuse silent fallback to active scope to prevent
   *    cross-tenant corpus leak).
   *  - scopeId provided + registry unmounted → active/cfg root (test stand-in).
   * @param scopeId - optional scope id; omit for the active scope.
   * @returns the resolved semantic-layer root path.
   */
  private resolveRoot;
  /**
   * GA-GT1 Phase 5a: PUBLIC per-scope root-resolution seam. Delegates to the
   * private `resolveRoot` (4-branch semantics unchanged) so consumer packages
   * (tool-retrieve/tool-search-data-sources/tool-search-schema enrichedLinkers
   * + retrieval-inproc scopedRetrievers) can resolve a scope's root for the
   * #19/#22 root-check fix (5b adds `root` to the per-scope cache entry +
   * checks `entry.root === root` — parity with the Phase 2 I-1
   * `graphCacheByScope` root guard). Dormant in 5a: no consumer calls it yet;
   * the method is exposed now so 5b can wire it through `SchemaCorpusSource`.
   *
   * 4 branches (same as `resolveRoot`):
   *  - scopeId undefined → active scope's root (backward-compatible).
   *  - scopeId provided + registry mounted + scope found → that scope's root.
   *  - scopeId provided + registry mounted + scope NOT found → throw
   *    (intranet-security: refuse silent fallback to active scope to prevent
   *    cross-tenant corpus leak).
   *  - scopeId provided + registry unmounted → active/cfg root (test stand-in).
   * @param scopeId - optional scope id; omit for the active scope.
   * @returns the resolved semantic-layer root path.
   */
  resolveScopeRoot(scopeId?: string): string;
  /**
   * The live data-source-kind registry (events/tables/metrics plugins registered at construction).
   * @returns the live data-source-kind registry.
   */
  getRegistry(): DataSourceRegistry;
  private graphCache;
  private graphVersion;
  /** GA-GT1 Phase 2 (D4 β): per-scope cache (plain Map; LRU eviction deferred
   * to Phase 3/4 — scope count is small) for `getRelationGraph(scopeId)` —
   * layered ALONGSIDE the existing instance cache (the no-arg path is
   * unchanged). Keyed by scopeId; each entry ALSO records the `root` the graph
   * was built from + `corpusVersionForRoot(root)`, so the entry is invalidated
   * when the version changes OR the scope is re-registered with a different
   * `semanticRoot` (cross-tenant corpus leak guard — I-1: without the root
   * check a re-registration onto a never-written root keeps version=0=0 and
   * the cache would silently serve the OLD root's graph). Phase 3/4 cleanup
   * unifies the two cache paths. */
  private readonly graphCacheByScope;
  /** CL-2 D2: dangling domain→concept refs collected during the last
   * getRelationGraph() build — assets whose `domains` reference a concept
   * name with no matching definition in concepts/. Such refs are SKIPPED
   * (warned) rather than aborting the build, so valid assets still get their
   * edges. Empty when all refs resolve (or no concepts are loaded). Exposed
   * via getDanglingDomainRefs() as a health-check surface. */
  private danglingDomainRefs;
  /**
   * The live relation graph: bidirectional adjacency over every table's
   * `dimension_refs` (joins), every event's `external_refs` (joins), and every
   * metric's `relations` (derived_from). Cached; rebuilt when the layer's
   * corpus-version counter advances (a write bumps it via `invalidateCaches`).
   * Events only enter the graph once `enrichAllEvents` has written their
   * `external_refs` (Part B).
   *
   * GA-GT1 Phase 2 (D4 β): an optional `scopeId` resolves a per-request scope's
   * root (via `resolveRoot`); the no-arg path is unchanged (active scope, single
   * instance cache — backward-compatible). The scopeId path uses a separate
   * per-scope cache (`graphCacheByScope` — plain Map, LRU eviction deferred to
   * Phase 3/4) keyed by scopeId + root + `corpusVersionForRoot(root)`. The root
   * is part of the cache key so re-registering the scope with a different
   * `semanticRoot` invalidates the entry even when the new root's content
   * counter is still 0 (I-1: cross-tenant corpus leak guard). It is acceptable
   * that `getRelationGraph()` and `getRelationGraph(activeId)` produce separate
   * cache entries for the same active scope (data is identical; duplicate entry
   * is harmless — Phase 3/4 cleanup unifies the two paths).
   * @param scopeId - optional scope id; omit to use the active scope (backward-compatible).
   * @returns the cached `RelationGraph`, rebuilt when stale.
   */
  getRelationGraph(scopeId?: string): RelationGraph;
  /**
   * GA-GT1 Phase 2: build a fresh `RelationGraph` from `root` — the ~60-line
   * build body shared by both the no-arg + per-scope paths of
   * `getRelationGraph`, so the build logic is NOT duplicated. Pure w.r.t.
   * cache state — the caller assigns the result to the relevant cache slot.
   * Updates `danglingDomainRefs` as a build side-effect (same as pre-Phase-2).
   */
  private buildGraph;
  /**
   * CL-2 D2: dangling domain→concept references collected during the last
   * `getRelationGraph()` build — assets whose `domains` reference a concept
   * name with no matching definition in concepts/. Such refs are skipped
   * (warned) rather than aborting the graph build, so valid assets still get
   * their edges. Empty when all domain refs resolve or no concepts are loaded.
   *
   * M-1: `danglingDomainRefs` is shared INSTANCE state — `buildGraph` is now
   * called by BOTH the no-arg + scopeId paths of `getRelationGraph`, so this
   * reflects the last build ACROSS ALL SCOPES (whichever `getRelationGraph`
   * call ran last), NOT a per-scope view. Per-scope keying of this health
   * surface is deferred to Phase 3/4 (scope count is small; the leak guard is
   * on the graph cache, not this health-check surface).
   * @returns a snapshot of the dangling refs (`asset="..." domain="..."`) from the last build (across all scopes).
   */
  getDanglingDomainRefs(): string[];
  /**
   * Registry-driven full retrieval corpus: every registered kind's definitions
   * projected via its `toCorpusItem` (events + tables + metrics). Supersedes
   * the events-only `loadRetrievalCorpus()` for P3/P4 — tables + metrics MUST
   * be indexable so BM25 can hit a DIM table (join recall) or a metric
   * (Level 2 context injection). `loadRetrievalCorpus()` is unchanged (preserves the
   * D2e events-only measured behavior + its 445-item K11 test).
   * @returns the full corpus (events + tables + metrics) ready for Bm25Linker.
   */
  loadRetrievalCorpusAll(): CorpusItem[];
  /**
   * Read one built-in kind's bespoke storage layout: `events` domain subdirs,
   * the flat `tables` dir, or the flat `concepts` dir, each validated by the
   * schema that owns that layout. Keyed by the built-in plugin instance rather
   * than by its `storageDir` string, because a kind registered later may
   * declare the same directory name and must not be handed another kind's
   * parsed shape (see {@link loadKindDefinitions}). `root` selects the scope
   * root to read.
   */
  private loadBuiltinDefinitions;
  /**
   * Registry-driven semantic-graph node projection (W27): every registered
   * kind's `toGraphNode` applied to each of its loaded definitions, followed by
   * the nodes those kinds derive through their declared `derivedNodes`
   * contributor (`metric` for `table` and `event`). Each kind contributes a node
   * or explicitly declines (`null`). Iterating the registry, rather than
   * hand-written per-kind loops, is what lets a kind registered later reach the
   * graph — with derived nodes included — without editing the projection.
   *
   * Uncached: it re-reads every registered kind's definitions from the ACTIVE
   * scope root on each call. The Schema Gateway threads a per-request `scopeId`
   * only to the relation-graph edge source, matching pre-W27 node-load behavior.
   * @param opts - `includeDerived` (default `true`) projects each kind's derived
   *  nodes; pass `false` to skip deriving nodes the caller discards.
   * @returns one projection per graph node: every registered kind's own nodes, then their derived nodes.
   */
  projectGraphNodes(opts?: {
    readonly includeDerived?: boolean;
  }): GraphNodeProjection[];
  /**
   * Load one kind's definitions from a scope root. Bespoke storage layouts
   * route through {@link loadBuiltinDefinitions}, selected by plugin identity.
   * Every other kind's dir is read generically (`loadRawDir` + the plugin's
   * OWN `schema.safeParse`), so a kind registered after build loads without a
   * hardcoded loader and keeps its own definition shape even when it declares
   * a directory name a built-in kind also uses. The `root` (W27) defaults to
   * the active scope root for `projectGraphNodes`; the relation-graph build
   * passes a per-scope root.
   */
  private loadKindDefinitions;
  /**
   * Mount a live-engine schema provider (P6b Q3 deferred; follow-up mounts the real one).
   * @param provider - the provider to delegate discover/describe/sample to, or undefined to clear.
   */
  setSchemaProvider(provider: SchemaProvider | undefined): void;
  /**
   * G3: inject (or clear) the one-shot LLM call used by the semantic relation
   * round. When undefined, `discoverRelations` + the on-write hook run the
   * deterministic PK-name round only. Production wires this to `ctx.llm`
   * (BlockAssembler-assembled text); the substrate itself stays free of the
   * LLM dependency.
   * @param fn - the llmCall to use, or undefined to run deterministic-only.
   */
  setLlmCall(fn?: LlmCall): void;
  /**
   * G3: discover DWS→DIM dimension relations for the layer (or a subset when
   * `tables` is given) and write them back into each DWS table's
   * `dimension_refs`. Delegates to the substrate `enrichAllDwsTables` (two-round
   * strategy; deterministic round always runs, LLM round runs only when a
   * `llmCall` is injected via `setLlmCall`). No Tier-2 audit — this is the
   * explicit enrichment entry (used by the `discover_relations` agent tool +
   * batch seeding); the on-write hook is the auto path.
   *
   * GA-GT3-5b: `preserveCurated` (default `true`) toggles the replace strategy
   * when `mergeExisting=false` (the default): `true` = origin-aware replace
   * (curated manual/undefined preserved, machine dropped — PR #43); `false` =
   * raw full-replace escape-hatch (ALL existing refs dropped, only discovered
   * remain — for the rare blow-away-rebuild case). Additive: default behavior
   * unchanged.
   * @param opts - optional `tables` filter + `preserveCurated` toggle (default true).
   * @returns `enriched` (DWS gaining >=1 ref) + `written` (DWS updated) + per-table `errors`.
   */
  discoverRelations(opts?: {
    readonly tables?: readonly string[];
    readonly preserveCurated?: boolean;
  }): Promise<{
    enriched: number;
    written: number;
    errors: string[];
    note?: string;
  }>;
  /**
   * Discover event→DIM relations (parallel to `discoverRelations` for DWS
   * tables) and write them into each event's `external_refs`. Delegates to the
   * substrate `enrichAllEvents` (two-round; deterministic always runs, LLM
   * round runs only when a `llmCall` is injected via `setLlmCall`). No Tier-2
   * audit — explicit enrichment entry.
   *
   * NOTE: an on-write hook for events (parallel to `enrichOnWrite` for tables)
   * is deferred: there is no Service-level event-write path today (events are
   * written via the substrate `writeEventYaml` raw-edit surface, not a Service
   * method). The hook lands with a future `syncWriteEvents`/`updateEventMeta`
   * Service method.
   *
   * GA-GT3-5b: `preserveCurated` (default `true`) toggles the replace strategy
   * (parallel to `discoverRelations`): `true` = origin-aware replace (curated
   * manual/undefined preserved, machine dropped — PR #43); `false` = raw
   * full-replace escape-hatch (ALL existing refs dropped, only discovered
   * remain). Additive: default behavior unchanged.
   * @param opts - optional `events` filter + `preserveCurated` toggle (default true).
   * @returns `enriched` (events gaining >=1 ref) + `written` (events updated) + per-event `errors`.
   */
  discoverEventRelations(opts?: {
    readonly events?: readonly string[];
    readonly preserveCurated?: boolean;
  }): Promise<{
    enriched: number;
    written: number;
    errors: string[];
    note?: string;
  }>;
  /**
   * CL-1 Phase 3: discover alt_labels (SKOS aliases) for definitions in the
   * layer. Two-round strategy: deterministic extraction from description/columns/
   * domains + optional LLM semantic suggestions. Merges with existing labels
   * (never removes curated aliases).
   *
   * @param opts - optional filters: `tables` (table_names) and/or `events` (event names).
   * @returns combined `enriched` + `written` + `errors` across tables and events.
   */
  discoverAltLabels(opts?: {
    readonly tables?: readonly string[];
    readonly events?: readonly string[];
  }): Promise<{
    enriched: number;
    written: number;
    errors: string[];
  }>;
  /**
   * G3 on-write hook: after a Service write, re-run DWS→DIM discovery for the
   * just-written tables and persist `dimension_refs` (best-effort: a failure
   * is logged, never propagated — it must not fail the originating write).
   * Also runs alt_labels discovery for the written tables (CL-1 Phase 3).
   * Uses the substrate `enrichAllDwsTables` (which writes via substrate
   * `writeTable`), so the hook does NOT re-enter the Service write path. DIM
   * tables are skipped by `enrichAllDwsTables`. Gated by `autoEnrich`.
   * @param names - the table_names just written via syncWrite/updateTableMeta.
   */
  private enrichOnWrite;
  /**
   * The on-write enrichment health records from the most recent write, or an
   * empty array when the last hook run fully succeeded (or did not run).
   *
   * A non-empty result means the just-written definitions are missing derived
   * facts (`dimension_refs` from the relation round, `alt_labels` from the
   * alt-labels round). The originating write still succeeded — the hook is
   * best-effort by design and never propagates — so this surface is how a
   * caller finds out that its write landed with incomplete enrichment and
   * whether to retry the round or degrade.
   *
   * Replaces four `ctx.logger.warn` call sites (slice 2 ②) that were the sole
   * exit for this information.
   * @returns a snapshot of the last run's health records.
   */
  getEnrichmentHealth(): readonly EnrichmentHealthEntry[];
  /** The semantic-layer scope root (the dir with config.yaml/events/tables), or
   * empty string when unset. P1: delegates to `ctx.scopes.active().semanticRoot`
   * when the scope-registry is mounted; otherwise falls back to static config. */
  get semanticRoot(): string;
  /** The default scope id for Tier-2 audit + schema discovery, or empty string
   * when unset. P1: delegates to `ctx.scopes.activeId()` when the scope-registry
   * is mounted; otherwise falls back to static config. */
  get scopeId(): string;
  /** D2h: the enrichment variant (mount-time config); 'params+term' (D2e-shipped) by default. */
  get corpusVariant(): CorpusVariant;
  /**
   * Load a validated event definition by name from the substrate.
   * @param name - the event `name` key to match.
   * @returns the parsed `EventDefinition`, or null when no event matches.
   */
  loadEventDefinition(name: string): EventDefinition | null;
  /**
   * Load a validated table definition by name from the substrate.
   * @param name - the table `table_name` key to match.
   * @param scopeId - GA-GT1 Phase 2: optional scope id; omit to use the active scope (backward-compatible).
   * @returns the parsed `TableDefinition`, or null when no table matches.
   */
  loadTableDefinition(name: string, scopeId?: string): TableDefinition | null;
  /**
   * Load a validated metric definition by name from the substrate.
   * @param name - the metric `name` key to match (`<host>__<key>`).
   * @returns the parsed `MetricDefinition`, or null when no host table/event defines a metric with this name.
   */
  loadMetricDefinition(name: string): MetricDefinition | null;
  /**
   * Load a validated concept definition by name from the substrate.
   * @param name - the concept `name` key to match.
   * @returns the parsed `ConceptDefinition`, or null when no concept matches.
   */
  loadConceptDefinition(name: string): ConceptDefinition | null;
  /**
   * Build an enriched retrieval corpus from the substrate — each event's
   * `alt_labels` (SKOS aliases) + `params_fields` packed into the indexed
   * `description`. The `corpusVariant` config selects slices: 'params+term'
   * (default) packs both; 'term-only' packs aliases only.
   * @param scopeId - GA-GT1 Phase 2: optional scope id; omit to use the active scope (backward-compatible).
   * @returns enriched corpus items ready for `Bm25Linker` / `HybridRetriever` indexing.
   */
  loadRetrievalCorpus(scopeId?: string): readonly EventCorpusItem[];
  /**
   * W11 C1: Capture a point-in-time snapshot of the semantic layer definitions.
   * The returned `DefinitionSnapshot` provides the same read API
   * (`loadTableDefinition`, `loadEventDefinition`, `loadMetricDefinition`,
   * `loadRetrievalCorpus`) but the data is pinned at the version when captured.
   * Subsequent `invalidateCaches()` calls (from management-session writes) do
   * NOT affect the returned snapshot. The next call to `acquireSnapshot` after
   * a write sees the new data.
   *
   * Cheap: if the corpus version has not changed since the last call, the
   * cached data arrays are reused (no disk re-scan).
   *
   * GA-GT1 Phase 2: an optional `scopeId` resolves a per-request scope's root
   * + corpus version (via `resolveRoot`/`corpusVersion(scopeId)`); the no-arg
   * path is unchanged (active scope — backward-compatible).
   * @param scopeId - optional scope id; omit to use the active scope (backward-compatible).
   * @returns a frozen `DefinitionSnapshot` pinned at the current corpus version.
   */
  acquireSnapshot(scopeId?: string): DefinitionSnapshot;
  /**
   * W11 C1: Execute `fn` with a consistent snapshot — definitions do not
   * reload mid-execution even if `invalidateCaches` fires concurrently (e.g.
   * from a management-session write). The snapshot is acquired before `fn` and
   * released after (release is a no-op in v1; reserved for future GC).
   *
   * Usage (in the NL2SQL query engine):
   * ```ts
   * const sql = await ctx.schema.withSnapshot(async (snap) => {
   *   const table = snap.loadTableDefinition('dws_pay_order_di')
   *   const event = snap.loadEventDefinition('game.pay.order')
   *   // ... generate SQL using pinned definitions ...
   *   return generatedSql
   * })
   * ```
   *
   * @param fn - the async function to execute with a pinned snapshot.
   * @returns the value returned by `fn`.
   */
  withSnapshot<T>(fn: (snap: DefinitionSnapshot) => Promise<T>): Promise<T>;
  /**
   * D2f (2026-08-21): the corpus-version counter for this layer - a monotonic
   * signal bumped by every writer via `invalidateCaches` (writeEventYaml /
   * writeTable / updateTableMeta / syncWriteDefinitions). Probed structurally
   * by `tool-search-data-sources` (no static dep) so its cached enriched
   * Bm25Linker rebuilds after a mid-session event edit instead of staying stale
   * until reboot (D2e-deferred cache-invalidation). Reads the per-path counter
   * for `this.semanticRoot` (0 until the first write).
   * @param scopeId - optional per-request scope; when omitted, the undefined (root) path's counter is read.
   * @returns the current corpus-version counter.
   */
  corpusVersion(scopeId?: string): number;
  /**
   * M-2: the corpus-version counter for a RESOLVED root — the substrate's
   * per-path content counter (0 until the first invalidateCaches on that
   * path). Factored out of the `corpusVersion(scopeId)` scopeId path so
   * `getRelationGraph(scopeId)` can resolve the root ONCE + reuse the version
   * without a second `resolveRoot` (which re-runs `scopes()`→
   * `ctx.get('scopes')`→`reg.get`→`load()`→`readFileSync`). The no-arg path
   * does NOT route here — it combines `scopeEpoch` + the active root's counter
   * inline (byte-for-byte unchanged).
   * @param root - the resolved semantic-layer root path.
   * @returns the per-path corpus-version counter for `root`.
   */
  private corpusVersionForRoot;
  /**
   * List tables in a scope (optionally filtered by kind) via the mounted provider.
   * @param scopeId - the scope to discover tables in.
   * @param kind - optional kind filter forwarded to the provider.
   * @returns a readonly array of table metas, or throws when no provider is mounted.
   */
  discover(scopeId: string, kind?: string): Promise<readonly TableMeta[]>;
  /**
   * Describe one table's columns/partitions/comment via the mounted provider.
   * @param tableName - the table name to describe.
   * @returns the table's meta, or null when the table is unknown / no provider is mounted.
   */
  describe(tableName: string): Promise<TableMeta | null>;
  /**
   * Sample N rows of a table as formatted text via the mounted provider.
   * @param tableName - the table name to sample.
   * @param n - optional row count to sample (provider default applies when omitted).
   * @returns the formatted sample text, or throws when no provider is mounted.
   */
  sample(tableName: string, n?: number): Promise<string>;
  /**
   * D5: inject the Tier-2 recorder. There is deliberately **no** way to turn
   * Tier-2 audit off — a host that wants audit-off behaviour must pass an
   * explicit no-op recorder that still satisfies the interface, making the
   * downgrade a deliberate, code-visible choice rather than a wiring accident
   * (ADR-0001).
   *
   * Setter-injected rather than looked up via `ctx.get('audit')` (slice 2 ②).
   * The guarantee is unchanged — an auditable mutation with no recorder still
   * throws — but the wiring is now legible at the call site instead of
   * depending on whether the host mounted something under the name `'audit'`.
   * @param recorder - the Tier-2 recorder, or undefined to clear (re-arming the throw).
   */
  setTier2Recorder(recorder: Tier2Recorder | undefined): void;
  /**
   * The wired Tier-2 recorder, or throw.
   *
   * **Invariant (D5)**: any code path that mutates auditable state MUST either
   * record the mutation via the wired `Tier2Recorder` or throw. Silent drop is
   * not a valid outcome (ADR-0001). This is the single chokepoint that enforces
   * it for the Service-level write methods.
   */
  private recorder;
  /**
   * Tier-2 persistent write: batch-generate/merge table YAML from pre-fetched
   * schema metas and write them to the substrate, recording each write via
   * `ctx.audit` (D5 non-disableable). Routes to `syncWriteDefinitions`. G3:
   * after the batch, the on-write hook re-runs DWS→DIM discovery for the
   * written tables (gated by `autoEnrich`).
   * @param tableMetas - the table metas to write (from discover/describe).
   * @param opts - optional dim-table-name set, existing-table map for merge, and scope id override.
   * @returns counts of written/skipped tables plus per-table error messages.
   */
  syncWrite(tableMetas: readonly TableMeta[], opts?: {
    readonly dimTableNames?: Set<string>;
    readonly existingTables?: Map<string, Record<string, unknown>>;
    readonly scopeId?: string;
  }): Promise<{
    written: number;
    skipped: number;
    errors: string[];
  }>;
  /**
   * Tier-2 per-scope write: read-merge-validate-write a single table's meta
   * updates, recording the write via `ctx.audit` (D5 non-disableable). G3:
   * after the write, the on-write hook re-runs DWS→DIM discovery for the table
   * (gated by `autoEnrich`).
   * @param name - the table `table_name` to update.
   * @param updates - the field overrides merged over the existing table YAML.
   * @param opts - optional scope id override (default scope id is used when omitted).
   * @returns `{ ok: true, table_name }` on success, or `{ ok: false, error }` when the table is missing/malformed or validation fails.
   */
  updateTableMeta(name: string, updates: Record<string, unknown>, opts?: {
    readonly scopeId?: string;
  }): Promise<{
    ok: true;
    table_name: string;
  } | {
    ok: false;
    error: string;
  }>;
  /**
   * Tier-2 per-scope write: read-merge-validate-write a single event's meta
   * updates, recording the write via `ctx.audit` (D5 non-disableable). Parallel
   * to `updateTableMeta` for the event substrate (A13 TOCTOU lost-update fix):
   * the substrate re-reads the latest on-disk event YAML at write time and
   * shallow-merges `updates` on top, so a concurrent edit between load+write
   * is no longer silently overwritten.
   *
   * The on-write event enrichment hook (parallel to `enrichOnWrite` for tables)
   * remains deferred — see the note on `discoverEventRelations`. This method
   * closes the "no Service-level event-write path" gap by routing through the
   * substrate `updateEventMeta` (Tier-2 audited) instead of the raw-edit
   * `writeEventYaml` surface.
   * @param name - the event `name` to update (must already exist on disk).
   * @param updates - the field overrides merged over the existing event YAML.
   * @param opts - optional scope id override (default scope id is used when omitted).
   * @returns `{ ok: true, event_name }` on success, or `{ ok: false, error }` when the event is missing/malformed or validation fails.
   */
  updateEventMeta(name: string, updates: Record<string, unknown>, opts?: {
    readonly scopeId?: string;
  }): Promise<{
    ok: true;
    event_name: string;
  } | {
    ok: false;
    error: string;
  }>;
}
/**
 * Stand-in live-engine schema provider (P6b Q3 deferred). Mirrors the P6
 * prototype's `schema-stub.mjs` fake tables so the decoupled sync flow
 * (discover -> TableMeta[] -> generate/merge YAML -> write) is demoable +
 * testable without the engine. Production mounts a real provider (follow-up).
 */
declare class StandInSchemaProvider implements SchemaProvider {
  private readonly tables;
  constructor(tables: Readonly<Record<string, TableMeta>>);
  discover(_scopeId: string, kind?: string): Promise<readonly TableMeta[]>;
  describe(tableName: string): Promise<TableMeta | null>;
  sample(tableName: string, n?: number): Promise<string>;
}
/**
 * A text-only LLM seam: `text(prompt) -> string`. Production `ctx.llm`
 * (BlockAssembler-assembled text) satisfies this once mounted. Declared here
 * so the substrate + the wiring adapter stay free of the LLM dependency.
 */
interface TextLlm {
  text(prompt: string): Promise<string>;
}
/**
 * Wire a text-LLM into a schema service's enrichment `llmCall` seam. After
 * this, `discoverRelations` / `discoverEventRelations` / the on-write hook
 * run the LLM semantic round (absent => deterministic round only).
 *
 * Production (once the bundle mounts `ctx.schema` + `ctx.llm`):
 *   `wireEnrichmentLlm(ctx.schema, ctx.llm)`
 * The adapter wraps `llm.text` as the substrate's `LlmCall = (prompt) => Promise<string>`.
 * @param schema - the `SemanticGroundingCore` (or a structural `{ setLlmCall }` test double).
 * @param llm - the text-LLM to adapt.
 */
declare function wireEnrichmentLlm(schema: {
  setLlmCall(fn?: (prompt: string) => Promise<string>): void;
}, llm: TextLlm): void;
//#endregion
export { type AltLabelsTarget, BasicIndex, CaliberVariant, CaliberVariantSchema, ColumnDef, ColumnDefSchema, ColumnMeta, ColumnMetaSchema, ConceptDefinition, ConceptDefinitionSchema, Confirmation, ConfirmationSchema, type CorpusItem, type CorpusVariant, CoverageDef, CoverageDefSchema, type CriticFields, type DataSourceKindPlugin, DataSourceRegistry, DefinitionSnapshot, type DerivedNodeContributor, type DimInventoryEntry, DimensionKeyPair, DimensionKeyPairSchema, DimensionRef, DimensionRefSchema, Disambiguation, DisambiguationSchema, EnrichmentHealthEntry, EnrichmentRound, type EventCorpusInput, type EventCorpusItem, EventDefinition, EventDefinitionSchema, type EventIndexEntry, type GraphNodeProjection, type KindGrouping, type LlmCall, MetricDef, MetricDefSchema, MetricDefinition, MetricDefinitionSchema, type NodeAliasData, ParamField, ParamFieldSchema, PartitionDef, PartitionDefSchema, PartitionMeta, PartitionMetaSchema, type PendingSuggestion, type RawConcept, type RawEvent, type RawTable, type RelationDef, type RelationEdge, RelationGraph, ResolvedSemanticLayerConfig, SNAPSHOT_CACHE_MAX, type SchemaLike, SchemaProvider, SemanticGroundingCore, SemanticGroundingCore as default, SemanticLayerConfig, StandInSchemaProvider, type SubmitArgs, SupersedesDef, SupersedesDefSchema, TableDefinition, TableDefinitionSchema, type TableIndexEntry, TableMeta, TableMetaSchema, TableTermDefaults, TableTermDefaultsSchema, TextLlm, type Tier2Opts, type Tier2Recorder, type UpdateEventMetaResult, type UpdateTableMetaResult, type WriteEventYamlResult, WriteValidationError, buildAltLabelsPrompt, buildDimInventory, buildEventLlmPrompt, buildExcludeColumns, buildLlmPrompt, buildRetrievalCorpus, canonicalizeType, captureSnapshot, clearSnapshotCache, conceptKindPlugin, deriveMetricRelations, discard, discoverAltLabels, discoverAltLabelsDeterministic, discoverAltLabelsFor, discoverEventRelationsDeterministic, discoverEventRelationsFor, discoverRelationsDeterministic, discoverRelationsFor, dumpYaml, enrichAllDwsTables, enrichAllEvents, enrichAllEventsAltLabels, enrichAllTablesAltLabels, eventKindPlugin, extractMetricsFromEvent, extractMetricsFromTable, extractMetricsFromTables, generateDimYaml, generateTableYaml, getSnapshotCacheSize, inferAggregation, inferRole, invalidateCaches, isValidId, listing, loadConceptDefinition, loadConcepts, loadConfig, loadDomains, loadEventDefinition, loadEvents, loadMetricDefinitions, load as loadPending, loadRawDir, loadRetrievalCorpus, loadTableDefinition, loadTables, mergeAltLabels, mergeChangedYaml, mergeColumns, mergeRefs, metricGraphNode, metricName, parseAltLabelsResponse, parseLlmRefs, projectMetricCorpusItem, resolveSemanticLayer, splitMetricName, submit, syncWriteDefinitions, tableKindPlugin, toMetricDefinition, updateEventMeta, updateTableMeta, wireEnrichmentLlm, writeEventYaml, writeTable };